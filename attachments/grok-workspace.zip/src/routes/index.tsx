import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import {
  FARMER,
  FOMC_AT,
  IF_THEN,
  REGIMES,
  SIGNED_SENTENCE_LOCKED,
  SIGNED_SENTENCE_REVISED,
  regimeFromFlags,
} from "@/data/invictus";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { RegimeBoard } from "@/components/regime-board";
import { Segment } from "@/components/ui/segment";
import { VerdictCard } from "@/components/verdict-card";
import { useHydrated } from "@/hooks/use-hydrated";
import { earners, idtlFlag, routeContribution, sufferers, walkBackActive } from "@/lib/engine";
import { selectPie, useInvictus } from "@/lib/store";

export const Route = createFileRoute("/")({ component: CommandPage });

function fomcCopy(now: Date): { title: string; sub: string } {
  const target = new Date(FOMC_AT);
  const ms = target.getTime() - now.getTime();
  if (ms <= 0) {
    return {
      title: "FOMC has occurred",
      sub: "Sign the sentence. Write the lock file. AutoInvest the next calendar day.",
    };
  }
  const hours = Math.floor(ms / 3_600_000);
  const days = Math.floor(hours / 24);
  const remH = hours % 24;
  return {
    title: days > 0 ? `${days}d ${remH}h to FOMC` : `${hours}h to FOMC`,
    sub: "16 September 2026, 19:00 BST. Sign after. Change AutoInvest on the 17th. Not before.",
  };
}

function idtlWatchCopy(gt30: number): string {
  const gap = Math.round((5.4 - gt30) * 1000) / 10;
  return `GT30 is ${gap.toFixed(1)}bp from the 5.40% flag. At 2% weight a 5% IDTL drop is 10bp of the pie. Rounding error.`;
}

function CommandPage() {
  const hydrated = useHydrated();
  const store = useInvictus();
  const pie = selectPie(store.pieMode);
  const regime = regimeFromFlags(store.growth, store.inflation);
  const meta = REGIMES.find((r) => r.id === regime)!;
  const routing = useMemo(
    () => routeContribution(pie, store),
    // store fields that actually change routing
    [
      pie,
      store.pmi,
      store.curveInverted,
      store.contribution,
      store.weights,
      store.growth,
      store.inflation,
      store.nav,
      store.gt30,
      store.signedAt,
      store.pieMode,
    ],
  );
  const now = hydrated ? new Date() : new Date("2026-09-14T00:34:00+01:00");
  const clock = fomcCopy(now);
  const wb = walkBackActive(store.pmi, store.curveInverted);
  const earn = earners(pie, regime);
  const hurt = sufferers(pie, regime);
  const sentence =
    store.pieMode === "revised" ? SIGNED_SENTENCE_REVISED : SIGNED_SENTENCE_LOCKED;

  return (
    <div className="space-y-10">
      <section className="rounded-xl bg-surface p-1">
        <div className="flex flex-col gap-3 rounded-lg bg-inset px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <div>
            <p className="stamp text-[10px] text-warn">{clock.title}</p>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">{clock.sub}</p>
          </div>
          <Button asChild variant="outline" size="sm">
            <Link to="/lock">Open lock file</Link>
          </Button>
        </div>
      </section>

      <header className="max-w-2xl">
        <p className="stamp text-[11px] text-subtle">Command</p>
        <h1 className="font-display mt-3 text-4xl leading-[1.1] tracking-tight sm:text-[2.75rem]">
          The machine does not need to know which regime comes next.
        </h1>
        <p className="mt-4 text-sm leading-relaxed text-muted">
          Something meaningful is working in every condition. The lines that fall
          are offset by the lines that rise. Contributions on the 3rd do the
          work. The signed sentence stays the hand.
        </p>
      </header>

      <blockquote className="font-display max-w-3xl border-l border-line pl-5 text-lg leading-relaxed text-fg italic sm:text-xl">
        {sentence}
      </blockquote>

      <section className="grid gap-8 lg:grid-cols-[1.15fr_0.85fr]">
        <div>
          <div className="mb-4 flex flex-wrap items-center gap-3">
            <Segment
              ariaLabel="Growth"
              value={store.growth}
              onChange={store.setGrowth}
              options={[
                { value: "up", label: "Growth ↑" },
                { value: "down", label: "Growth ↓" },
              ]}
            />
            <Segment
              ariaLabel="Inflation"
              value={store.inflation}
              onChange={store.setInflation}
              options={[
                { value: "up", label: "Inflation ↑" },
                { value: "down", label: "Inflation ↓" },
              ]}
            />
          </div>
          <RegimeBoard
            active={regime}
            onSelect={(id) => {
              const r = REGIMES.find((x) => x.id === id)!;
              store.setGrowth(r.growth);
              store.setInflation(r.inflation);
            }}
          />
          <p className="mt-4 text-sm leading-relaxed text-muted">{meta.response}</p>
        </div>

        <div className="space-y-4">
          <div className="rounded-xl bg-surface p-5">
            <p className="stamp text-[10px] text-subtle">Who earns</p>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {earn.map((l) => (
                <Badge key={l.ticker} tone="earn">
                  {l.ticker}
                </Badge>
              ))}
            </div>
            <p className="stamp mt-5 text-[10px] text-subtle">Who suffers</p>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {hurt.map((l) => (
                <Badge key={l.ticker} tone="suffer">
                  {l.ticker}
                </Badge>
              ))}
            </div>
          </div>
          <div className="rounded-xl bg-surface p-5">
            <p className="stamp text-[10px] text-subtle">Sensors</p>
            <dl className="mt-3 space-y-2 text-sm">
              <div className="flex justify-between gap-4">
                <dt className="text-muted">Walk-back</dt>
                <dd className={wb ? "text-warn" : "text-earn"}>
                  {wb ? "Active — 100% XSTR" : "Inactive"}
                </dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-muted">PMI</dt>
                <dd className="tabular">{store.pmi.toFixed(1)}</dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-muted">2s10s</dt>
                <dd>{store.curveInverted ? "Inverted" : "Not inverted"}</dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-muted">GT30 / IDTL flag</dt>
                <dd className={idtlFlag(store.gt30) ? "text-warn tabular" : "tabular"}>
                  {store.gt30.toFixed(3)}% {idtlFlag(store.gt30) ? "· flag" : ""}
                </dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-muted">NAV</dt>
                <dd className="tabular">£{store.nav.toLocaleString("en-GB")}</dd>
              </div>
            </dl>
            {idtlFlag(store.gt30) ? (
              <p className="mt-3 text-xs leading-relaxed text-warn">
                Duration-hit flag. Do not sell. The spring is being compressed further.
              </p>
            ) : (
              <p className="mt-3 text-xs leading-relaxed text-subtle">
                {idtlWatchCopy(store.gt30)}
              </p>
            )}
          </div>
        </div>
      </section>

      <section>
        <div className="mb-4 flex items-end justify-between gap-4">
          <div>
            <p className="stamp text-[11px] text-subtle">This month · the 3rd</p>
            <h2 className="font-display mt-2 text-2xl">Contribution routing</h2>
          </div>
          <Button asChild variant="ghost" size="sm">
            <Link to="/decide">Full protocol</Link>
          </Button>
        </div>
        <VerdictCard verdict={routing} />
      </section>

      <section className="grid gap-4 sm:grid-cols-3">
        {[
          { k: "Look-through equity", v: "~57%" },
          { k: "Planning drawdown", v: "30–35%" },
          {
            k: store.pieMode === "revised" ? "2022 stress (revised)" : "2022 stress (lock)",
            v: store.pieMode === "revised" ? "−2.11%" : "−3.69%",
          },
        ].map((s) => (
          <div key={s.k} className="rounded-xl bg-surface px-5 py-4">
            <p className="text-[11px] uppercase tracking-[0.14em] text-subtle">{s.k}</p>
            <p className="font-display mt-2 text-2xl tabular">{s.v}</p>
          </div>
        ))}
      </section>

      <section className="max-w-2xl">
        <p className="font-display text-lg leading-relaxed text-muted italic">{FARMER}</p>
        <p className="mt-4 text-sm leading-relaxed text-subtle">{IF_THEN}</p>
      </section>
    </div>
  );
}
