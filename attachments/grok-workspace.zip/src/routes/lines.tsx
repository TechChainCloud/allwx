import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  COOPERATION,
  FARMER_MAP,
  REGIMES,
  regimeFromFlags,
  type Line,
  type RegimeFit,
} from "@/data/invictus";
import { Badge } from "@/components/ui/badge";
import { PieDonut } from "@/components/pie-donut";
import { selectPie, useInvictus } from "@/lib/store";
import { cn, formatPct } from "@/lib/utils";

export const Route = createFileRoute("/lines")({ component: LinesPage });

type Filter = "all" | "1" | "2";

function fitTone(fit: RegimeFit): "earn" | "suffer" | "hold" {
  if (fit === "earn") return "earn";
  if (fit === "suffer") return "suffer";
  return "hold";
}

function LinesPage() {
  const store = useInvictus();
  const pie = selectPie(store.pieMode);
  const regime = regimeFromFlags(store.growth, store.inflation);
  const [filter, setFilter] = useState<Filter>("all");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<string | null>(pie[0]?.ticker ?? "VWRP");

  const visible = useMemo(() => {
    const query = q.trim().toLowerCase();
    return pie.filter((l) => {
      if (filter === "1" && l.sleeve !== 1) return false;
      if (filter === "2" && l.sleeve !== 2) return false;
      if (!query) return true;
      return (
        l.ticker.toLowerCase().includes(query) ||
        l.name.toLowerCase().includes(query) ||
        l.job.toLowerCase().includes(query)
      );
    });
  }, [pie, filter, q]);

  const s1 = pie.filter((l) => l.sleeve === 1).reduce((s, l) => s + l.weight, 0);
  const s2 = pie.filter((l) => l.sleeve === 2).reduce((s, l) => s + l.weight, 0);

  return (
    <div className="space-y-8">
      <header className="max-w-2xl">
        <p className="stamp text-[11px] text-subtle">
          {store.pieMode === "revised" ? "Revised pie" : "Locked 12 Sep 2026"}
        </p>
        <h1 className="font-display mt-3 text-4xl tracking-tight">Sixteen lines. Sixteen jobs.</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          No line suffers alone. No line earns alone. The cycle always moves
          through all four quadrants, given enough time.
        </p>
      </header>

      <div className="grid items-center gap-8 md:grid-cols-[220px_1fr]">
        <PieDonut pie={pie} />
        <div className="grid grid-cols-2 gap-3">
          <Stat k="Sleeve 1 · growth & real" v={`${s1.toFixed(1)}%`} />
          <Stat k="Sleeve 2 · defensive" v={`${s2.toFixed(1)}%`} />
          <Stat k="Equity look-through" v="~57%" />
          <Stat k="Real assets" v="18%" />
        </div>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="flex rounded-md bg-inset p-1 shadow-[var(--shadow-border)]">
          {(
            [
              ["all", "All"],
              ["1", "Sleeve 1"],
              ["2", "Sleeve 2"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setFilter(id)}
              className={cn(
                "h-9 rounded-sm px-3 text-xs font-medium",
                filter === id ? "bg-accent text-accent-fg" : "text-muted",
              )}
            >
              {label}
            </button>
          ))}
        </div>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search ticker, job…"
          className="h-11 flex-1 rounded-md bg-surface px-3 text-sm text-fg shadow-[var(--shadow-border)] placeholder:text-subtle"
        />
      </div>

      <ul className="space-y-2">
        {visible.map((line) => (
          <LineRow
            key={line.ticker}
            line={line}
            regime={regime}
            open={open === line.ticker}
            onToggle={() => setOpen(open === line.ticker ? null : line.ticker)}
          />
        ))}
      </ul>

      <section>
        <h2 className="font-display text-2xl">Cooperation map</h2>
        <p className="mt-2 max-w-prose text-sm text-muted">
          Every line has at least one partner that earns when it suffers.
        </p>
        <div className="mt-4 divide-y divide-line overflow-hidden rounded-xl bg-surface">
          {COOPERATION.map((row) => (
            <div key={row.suffers} className="grid gap-1 px-5 py-3 sm:grid-cols-2 sm:gap-6">
              <p className="text-sm text-suffer">{row.suffers}</p>
              <p className="text-sm text-earn">{row.earns}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-xl bg-surface px-4 py-4">
      <p className="text-[11px] uppercase tracking-[0.14em] text-subtle">{k}</p>
      <p className="font-display mt-2 text-2xl tabular">{v}</p>
    </div>
  );
}

function LineRow({
  line,
  regime,
  open,
  onToggle,
}: {
  line: Line;
  regime: ReturnType<typeof regimeFromFlags>;
  open: boolean;
  onToggle: () => void;
}) {
  const fit = line.regimes[regime];
  return (
    <li className="rounded-xl bg-surface">
      <button
        type="button"
        onClick={onToggle}
        className="flex w-full items-center gap-3 px-4 py-3 text-left sm:px-5"
        aria-expanded={open}
      >
        <span className="w-14 text-sm tracking-wide">{line.ticker}</span>
        <span className="hidden flex-1 truncate text-sm text-muted sm:block">{line.job}</span>
        <span className="ml-auto flex items-center gap-2">
          <Badge tone={fitTone(fit)}>{fit}</Badge>
          <span className="tabular text-sm text-fg">{line.weight.toFixed(1)}%</span>
        </span>
      </button>
      {open ? (
        <div className="border-t border-line px-4 py-5 sm:px-5">
          <p className="text-sm font-medium text-fg">{line.name}</p>
          <p className="mt-2 max-w-prose text-sm leading-relaxed text-muted">{line.story}</p>
          <p className="font-display mt-3 text-[15px] text-fg italic">{line.analogy}</p>
          {FARMER_MAP[line.ticker] ? (
            <p className="mt-2 text-xs text-subtle">On the farm: {FARMER_MAP[line.ticker]}.</p>
          ) : (
            <p className="mt-2 text-xs text-subtle">
              Specialist tool — a small job no other line does.
            </p>
          )}
          <dl className="mt-5 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
            <Mini k="Floor–cap" v={`${line.floor}–${line.cap}%`} />
            <Mini k="5-year" v={formatPct(line.fiveYear, 1)} />
            <Mini k="2022" v={line.y2022 === null ? "n/a*" : formatPct(line.y2022, 1)} />
            <Mini k="TER" v={line.ter} />
          </dl>
          <div className="mt-4 flex flex-wrap gap-1.5">
            {REGIMES.map((r) => (
              <Badge key={r.id} tone={fitTone(line.regimes[r.id])}>
                {r.name}: {line.regimes[r.id]}
              </Badge>
            ))}
          </div>
          {line.partnersWhenSuffers.length > 0 ? (
            <p className="mt-4 text-xs text-muted">
              When this suffers:{" "}
              <span className="text-earn">{line.partnersWhenSuffers.join(", ")}</span>
            </p>
          ) : null}
          {line.probation ? (
            <p className="mt-2 text-xs text-warn">{line.probation}</p>
          ) : null}
          {line.notes ? <p className="mt-2 text-xs text-subtle">{line.notes}</p> : null}
        </div>
      ) : null}
    </li>
  );
}

function Mini({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <dt className="text-[10px] uppercase tracking-[0.14em] text-subtle">{k}</dt>
      <dd className="mt-1 tabular text-fg">{v}</dd>
    </div>
  );
}
