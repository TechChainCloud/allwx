import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  MILESTONE_1M,
  PLAN_PATHS,
  STATS_LOCKED,
  STATS_REVISED,
  STRESS_SCENARIOS,
  YEARLY_REVISED,
} from "@/data/invictus";
import { Button } from "@/components/ui/button";
import { pathSeries } from "@/lib/engine";
import { useInvictus } from "@/lib/store";
import { cn, formatCompactGbp, formatGbp, formatPct } from "@/lib/utils";

export const Route = createFileRoute("/path")({ component: PathPage });

type Scenario = "stress" | "bayesian" | "historical";

function PathPage() {
  const contribution = useInvictus((s) => s.contribution);
  const setContribution = useInvictus((s) => s.setContribution);
  const pieMode = useInvictus((s) => s.pieMode);
  const [scenario, setScenario] = useState<Scenario>("bayesian");
  const stats = pieMode === "revised" ? STATS_REVISED : STATS_LOCKED;
  const plan = PLAN_PATHS[scenario];

  const chart = useMemo(() => {
    const years = 30;
    const stress = pathSeries(contribution, 0.05, years);
    const bayes = pathSeries(contribution, 0.075, years);
    const hist = pathSeries(contribution, 0.0818, years);
    return Array.from({ length: years }, (_, i) => ({
      year: i + 1,
      stress: Math.round(stress[i]!),
      bayesian: Math.round(bayes[i]!),
      historical: Math.round(hist[i]!),
    }));
  }, [contribution]);

  const terminal = chart[29]!;

  return (
    <div className="space-y-10">
      <header className="max-w-2xl">
        <p className="stamp text-[11px] text-subtle">Thirty years</p>
        <h1 className="font-display mt-3 text-4xl tracking-tight">
          Plan around 5%. Work from 7.5%. Do not plan around history.
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          Getting to £1,600 a month is the single most important lever. At
          £200/month the contribution is the binding constraint — not the
          portfolio.
        </p>
      </header>

      <div className="grid gap-3 sm:grid-cols-4">
        <Stat k="Mean (verified)" v={formatPct(stats.mean, 2)} />
        <Stat k="Volatility" v={formatPct(stats.vol, 2)} />
        <Stat k={`Worst year (${stats.worst.year})`} v={formatPct(stats.worst.value, 2)} />
        <Stat k={`Best year (${stats.best.year})`} v={formatPct(stats.best.value, 2)} />
      </div>

      <section className="rounded-xl bg-surface p-4 sm:p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <label className="block max-w-xs">
            <span className="mb-2 block text-[11px] uppercase tracking-[0.14em] text-subtle">
              Monthly contribution
            </span>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min={200}
                max={1667}
                step={50}
                value={contribution}
                onChange={(e) => setContribution(Number(e.target.value))}
                className="h-11 w-48 accent-[var(--color-accent)]"
              />
              <span className="tabular text-lg text-fg">{formatGbp(contribution)}</span>
            </div>
          </label>
          <div className="flex rounded-md bg-inset p-1">
            {(
              [
                ["stress", "5.0%"],
                ["bayesian", "7.5%"],
                ["historical", "8.18%"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setScenario(id)}
                className={cn(
                  "h-9 rounded-sm px-3 text-xs font-medium",
                  scenario === id ? "bg-accent text-accent-fg" : "text-muted",
                )}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-6 h-64 sm:h-80">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chart} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="fillPath" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--color-accent)" stopOpacity={0.28} />
                  <stop offset="100%" stopColor="var(--color-accent)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="var(--color-line)" vertical={false} />
              <XAxis
                dataKey="year"
                type="number"
                domain={[1, 30]}
                tick={{ fill: "var(--color-subtle)", fontSize: 11 }}
                axisLine={false}
                tickLine={false}
                ticks={[5, 10, 15, 20, 25, 30]}
              />
              <YAxis
                tickFormatter={(v) => formatCompactGbp(Number(v))}
                tick={{ fill: "var(--color-subtle)", fontSize: 11 }}
                axisLine={false}
                tickLine={false}
                width={56}
              />
              <Tooltip
                contentStyle={{
                  background: "var(--color-surface)",
                  border: "1px solid var(--color-line)",
                  borderRadius: 8,
                  color: "var(--color-fg)",
                }}
                formatter={(value) => formatGbp(Number(value))}
                labelFormatter={(y) => `Year ${y}`}
              />
              <Area
                type="monotone"
                dataKey={scenario}
                stroke="var(--color-accent)"
                fill="url(#fillPath)"
                strokeWidth={1.75}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <p className="mt-3 text-sm text-muted">
          {plan.label}. Year 30 at this contribution:{" "}
          <span className="tabular text-fg">{formatGbp(terminal[scenario])}</span>
        </p>
      </section>

      <section>
        <h2 className="font-display text-2xl">Lock-file path at £1,600 / month</h2>
        <p className="mt-2 text-sm text-muted">
          Official planning table. Live chart above uses monthly compounding and
          will differ slightly.
        </p>
        <div className="mt-4 overflow-x-auto rounded-xl bg-surface">
          <table className="w-full min-w-[28rem] text-left text-sm">
            <thead>
              <tr className="border-b border-line text-[10px] uppercase tracking-[0.14em] text-subtle">
                <th className="px-4 py-3 font-medium">Year</th>
                <th className="px-4 py-3 font-medium">Stress 5.0%</th>
                <th className="px-4 py-3 font-medium">Bayesian 7.5%</th>
                <th className="px-4 py-3 font-medium">Historical 8.18%</th>
              </tr>
            </thead>
            <tbody>
              {([5, 10, 15, 20, 25, 30] as const).map((y) => (
                <tr key={y} className="border-b border-line/70 last:border-0">
                  <td className="px-4 py-2.5 tabular text-muted">{y}</td>
                  <td className="px-4 py-2.5 tabular">{formatGbp(PLAN_PATHS.stress.at1600[y]!)}</td>
                  <td className="px-4 py-2.5 tabular">{formatGbp(PLAN_PATHS.bayesian.at1600[y]!)}</td>
                  <td className="px-4 py-2.5 tabular">{formatGbp(PLAN_PATHS.historical.at1600[y]!)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section>
        <h2 className="font-display text-2xl">£1M milestone</h2>
        <div className="mt-4 overflow-x-auto rounded-xl bg-surface">
          <table className="w-full min-w-[28rem] text-left text-sm">
            <thead>
              <tr className="border-b border-line text-[10px] uppercase tracking-[0.14em] text-subtle">
                <th className="px-4 py-3 font-medium">Scenario</th>
                <th className="px-4 py-3 font-medium">£200 / mo</th>
                <th className="px-4 py-3 font-medium">£1,600 / mo</th>
                <th className="px-4 py-3 font-medium">ISA max</th>
              </tr>
            </thead>
            <tbody>
              {(["stress", "bayesian", "historical"] as const).map((id) => (
                <tr key={id} className="border-b border-line/70 last:border-0">
                  <td className="px-4 py-2.5 capitalize text-muted">{id}</td>
                  <td className="px-4 py-2.5">{MILESTONE_1M[id]["200"]}</td>
                  <td className="px-4 py-2.5">{MILESTONE_1M[id]["1600"]}</td>
                  <td className="px-4 py-2.5">{MILESTONE_1M[id]["1667"]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={() => setContribution(1600)}>
            Set £1,600
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setContribution(1667)}>
            ISA maximum
          </Button>
        </div>
      </section>

      <section>
        <h2 className="font-display text-2xl">Verified years (revised pie)</h2>
        <ul className="mt-4 divide-y divide-line overflow-hidden rounded-xl bg-surface">
          {YEARLY_REVISED.map((y) => (
            <li key={y.year} className="flex flex-col gap-1 px-5 py-3 sm:flex-row sm:items-baseline sm:gap-6">
              <span className="w-12 tabular text-sm text-muted">{y.year}</span>
              <span
                className={cn(
                  "w-20 tabular text-sm",
                  y.ret < 0 ? "text-suffer" : "text-earn",
                )}
              >
                {formatPct(y.ret, 2)}
              </span>
              <span className="text-sm text-muted">{y.driver}</span>
            </li>
          ))}
        </ul>
      </section>

      <section>
        <h2 className="font-display text-2xl">Stress scenarios</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {STRESS_SCENARIOS.map((s) => (
            <article key={s.id} className="rounded-xl bg-surface px-5 py-4">
              <p className="text-sm font-medium text-fg">{s.name}</p>
              <p className="mt-2 tabular text-lg text-fg">{s.impact}</p>
              <p className="mt-2 text-xs leading-relaxed text-muted">{s.cushion}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-xl bg-surface px-4 py-4">
      <p className="text-[11px] uppercase tracking-[0.14em] text-subtle">{k}</p>
      <p className="font-display mt-2 text-2xl tabular">{v}</p>
    </div>
  );
}
