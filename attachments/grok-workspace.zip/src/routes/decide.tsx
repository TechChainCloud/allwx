import type { ReactNode } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  LOCKED_PIE,
  PERMANENTLY_DEAD,
  REVISED_PIE,
  SIZE_GATES,
} from "@/data/invictus";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Segment } from "@/components/ui/segment";
import { VerdictCard } from "@/components/verdict-card";
import {
  routeContribution,
  verdictAddLine,
  verdictAutoInvest,
  verdictDead,
  verdictSell,
  verdictSizeGate,
  walkBackActive,
  type Verdict,
} from "@/lib/engine";
import { selectPie, useInvictus } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/decide")({ component: DecidePage });

type Intent =
  | "contribute"
  | "sell"
  | "autoinvest"
  | "walkback"
  | "addline"
  | "gates"
  | "dead";

const INTENTS: { id: Intent; title: string; blurb: string }[] = [
  { id: "contribute", title: "Route this month’s contribution", blurb: "The 3rd does the work. Nothing is sold." },
  { id: "sell", title: "Should I sell a line?", blurb: "The signed sentence already answered." },
  { id: "autoinvest", title: "Change AutoInvest", blurb: "Lock file first. Decision date first." },
  { id: "walkback", title: "Has walk-back fired?", blurb: "PMI < 50 and 2s10s inverted." },
  { id: "addline", title: "Add a 17th line", blurb: "No 17th personality." },
  { id: "gates", title: "Size-gate a replacement", blurb: "FLOT, VHYL, ROLL — gates, not orders." },
  { id: "dead", title: "Revive a dead idea", blurb: "D-Prime, IITU, crypto, 8% planning return." },
];

function DecidePage() {
  const store = useInvictus();
  const pie = selectPie(store.pieMode);
  const [intent, setIntent] = useState<Intent>("contribute");
  const [sellTicker, setSellTicker] = useState("VAGS");
  const [addTicker, setAddTicker] = useState("IITU");
  const [gateId, setGateId] = useState<(typeof SIZE_GATES)[number]["id"]>("FLOT");
  const [deadId, setDeadId] = useState(PERMANENTLY_DEAD[0]!.id);

  const allTickers = useMemo(() => {
    const set = new Set<string>();
    for (const l of LOCKED_PIE) set.add(l.ticker);
    for (const l of REVISED_PIE) set.add(l.ticker);
    return [...set];
  }, []);

  const verdict: Verdict = useMemo(() => {
    switch (intent) {
      case "contribute":
        return routeContribution(pie, store);
      case "sell":
        return verdictSell(pie, sellTicker);
      case "autoinvest":
        return verdictAutoInvest(store);
      case "walkback": {
        const active = walkBackActive(store.pmi, store.curveInverted);
        if (active) return routeContribution(pie, store);
        return {
          kind: "hold",
          stamp: "WALK-BACK INACTIVE",
          rule: "PMI < 50 AND 2s10s inverted. Both must be true.",
          reason: `PMI is ${store.pmi.toFixed(1)}${store.pmi < 50 ? " (below 50)" : " (above 50)"} and the curve is ${store.curveInverted ? "inverted" : "not inverted"}. Contributions follow floors, caps and target weights. Satellites are not zeroed.`,
          ifThen:
            "If the front line is intact, the reserve stays the reserve. Do not hide in cash because a single line had a bad month.",
        };
      }
      case "addline":
        return verdictAddLine(addTicker);
      case "gates":
        return verdictSizeGate(gateId, store.nav);
      case "dead":
        return verdictDead(deadId);
    }
  }, [intent, pie, store, sellTicker, addTicker, gateId, deadId]);

  return (
    <div className="space-y-8">
      <header className="max-w-2xl">
        <p className="stamp text-[11px] text-subtle">Protocol</p>
        <h1 className="font-display mt-3 text-4xl tracking-tight">Decide</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          Name the action. The machine applies the lock file. A briefing is not
          a change log entry.
        </p>
      </header>

      <div className="grid gap-2 sm:grid-cols-2">
        {INTENTS.map((item) => {
          const on = item.id === intent;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setIntent(item.id)}
              className={cn(
                "rounded-xl px-4 py-4 text-left transition-colors duration-150",
                on ? "bg-accent text-accent-fg" : "bg-surface hover:bg-elevated",
              )}
            >
              <p className="text-sm font-medium">{item.title}</p>
              <p className={cn("mt-1 text-xs leading-relaxed", on ? "text-accent-fg/75" : "text-muted")}>
                {item.blurb}
              </p>
            </button>
          );
        })}
      </div>

      {intent === "contribute" ? (
        <ControlsPanel>
          <Field label="This month’s contribution">
            <NumberField
              value={store.contribution}
              onChange={store.setContribution}
              prefix="£"
              step={50}
              min={0}
            />
          </Field>
          <Field label="PMI">
            <NumberField
              value={store.pmi}
              onChange={store.setPmi}
              step={0.1}
              min={20}
              max={80}
            />
          </Field>
          <Field label="2s10s curve">
            <Segment
              ariaLabel="Curve"
              value={store.curveInverted ? "inv" : "norm"}
              onChange={(v) => store.setCurveInverted(v === "inv")}
              options={[
                { value: "norm", label: "Not inverted" },
                { value: "inv", label: "Inverted" },
              ]}
            />
          </Field>
        </ControlsPanel>
      ) : null}

      {intent === "sell" ? (
        <ControlsPanel>
          <Field label="Line under review">
            <select
              value={sellTicker}
              onChange={(e) => setSellTicker(e.target.value)}
              className="h-11 w-full rounded-md bg-inset px-3 text-sm text-fg shadow-[var(--shadow-border)]"
            >
              {allTickers.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </Field>
        </ControlsPanel>
      ) : null}

      {intent === "walkback" ? (
        <ControlsPanel>
          <Field label="PMI">
            <NumberField value={store.pmi} onChange={store.setPmi} step={0.1} min={20} max={80} />
          </Field>
          <Field label="2s10s curve">
            <Segment
              ariaLabel="Curve"
              value={store.curveInverted ? "inv" : "norm"}
              onChange={(v) => store.setCurveInverted(v === "inv")}
              options={[
                { value: "norm", label: "Not inverted" },
                { value: "inv", label: "Inverted" },
              ]}
            />
          </Field>
        </ControlsPanel>
      ) : null}

      {intent === "addline" ? (
        <ControlsPanel>
          <Field label="Proposed ticker">
            <input
              value={addTicker}
              onChange={(e) => setAddTicker(e.target.value.toUpperCase())}
              className="h-11 w-full rounded-md bg-inset px-3 text-sm tracking-wide text-fg shadow-[var(--shadow-border)]"
              placeholder="IITU"
            />
          </Field>
        </ControlsPanel>
      ) : null}

      {intent === "gates" ? (
        <ControlsPanel>
          <Field label="Gate">
            <Segment
              ariaLabel="Size gate"
              value={gateId}
              onChange={(v) => setGateId(v as typeof gateId)}
              options={SIZE_GATES.map((g) => ({ value: g.id, label: g.id }))}
            />
          </Field>
          <Field label="ISA NAV">
            <NumberField value={store.nav} onChange={store.setNav} prefix="£" step={50} min={0} />
          </Field>
        </ControlsPanel>
      ) : null}

      {intent === "dead" ? (
        <ControlsPanel>
          <div className="flex flex-wrap gap-1.5">
            {PERMANENTLY_DEAD.map((d) => (
              <button key={d.id} type="button" onClick={() => setDeadId(d.id)}>
                <Badge tone={deadId === d.id ? "invert" : "default"}>{d.name}</Badge>
              </button>
            ))}
          </div>
        </ControlsPanel>
      ) : null}

      {intent === "autoinvest" ? (
        <p className="text-sm text-muted">
          Working pie:{" "}
          <span className="text-fg">{store.pieMode === "revised" ? "Revised" : "12 September lock"}</span>
          {store.signedAt ? " · signed" : " · unsigned"}
        </p>
      ) : null}

      <VerdictCard verdict={verdict} />

      {intent === "contribute" ? <WeightsEditor /> : null}
    </div>
  );
}

function ControlsPanel({ children }: { children: ReactNode }) {
  return (
    <div className="grid gap-4 rounded-xl bg-surface p-4 sm:grid-cols-3 sm:p-5">
      {children}
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="block">
      <span className="mb-2 block text-[11px] uppercase tracking-[0.14em] text-subtle">
        {label}
      </span>
      {children}
    </div>
  );
}

function NumberField({
  value,
  onChange,
  prefix,
  step = 1,
  min,
  max,
}: {
  value: number;
  onChange: (n: number) => void;
  prefix?: string;
  step?: number;
  min?: number;
  max?: number;
}) {
  return (
    <div className="relative">
      {prefix ? (
        <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm text-subtle">
          {prefix}
        </span>
      ) : null}
      <input
        type="number"
        value={Number.isFinite(value) ? value : 0}
        step={step}
        min={min}
        max={max}
        onChange={(e) => onChange(Number(e.target.value))}
        className={cn(
          "h-11 w-full rounded-md bg-inset text-sm tabular text-fg shadow-[var(--shadow-border)]",
          prefix ? "pl-7 pr-3" : "px-3",
        )}
      />
    </div>
  );
}

function WeightsEditor() {
  const store = useInvictus();
  const pie = selectPie(store.pieMode);
  const sum = pie.reduce((s, l) => s + (store.weights[l.ticker] ?? l.weight), 0);

  return (
    <section>
      <div className="mb-3 flex items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-xl">Current weights</h2>
          <p className="mt-1 text-xs text-muted">
            Drift the pie to see how the 3rd rebalances. Sum {sum.toFixed(1)}%.
          </p>
        </div>
        <Button variant="ghost" size="sm" onClick={store.resetWeights}>
          Reset to target
        </Button>
      </div>
      <div className="overflow-hidden rounded-xl bg-surface">
        <div className="grid grid-cols-[1fr_4.5rem_5.5rem] gap-2 border-b border-line px-4 py-2 text-[10px] uppercase tracking-[0.14em] text-subtle">
          <span>Line</span>
          <span className="text-right">Now</span>
          <span className="text-right">Target</span>
        </div>
        {pie.map((l) => {
          const w = store.weights[l.ticker] ?? l.weight;
          const drift = w - l.weight;
          return (
            <div
              key={l.ticker}
              className="grid grid-cols-[1fr_4.5rem_5.5rem] items-center gap-2 border-b border-line/70 px-4 py-2 last:border-0"
            >
              <div>
                <p className="text-sm">{l.ticker}</p>
                <p className="text-[11px] text-subtle">
                  {l.floor}–{l.cap}%
                  {w < l.floor ? " · below floor" : w > l.cap ? " · above cap" : ""}
                </p>
              </div>
              <input
                type="number"
                step={0.5}
                min={0}
                max={60}
                value={w}
                onChange={(e) => store.setWeight(l.ticker, Number(e.target.value))}
                className="h-10 rounded-sm bg-inset px-2 text-right text-sm tabular text-fg"
              />
              <span
                className={cn(
                  "text-right text-sm tabular",
                  drift > 0.2 ? "text-warn" : drift < -0.2 ? "text-hold" : "text-muted",
                )}
              >
                {l.weight.toFixed(1)}
              </span>
            </div>
          );
        })}
      </div>
    </section>
  );
}
