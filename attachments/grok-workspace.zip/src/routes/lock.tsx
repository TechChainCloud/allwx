import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  AUTOINVEST_ON,
  FOMC_AT,
  GOVERNANCE,
  IF_THEN,
  LOCK_ENTRIES,
  PERMANENTLY_DEAD,
  SIGN_AFTER,
  SIGNED_SENTENCE_LOCKED,
  SIGNED_SENTENCE_REVISED,
} from "@/data/invictus";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Segment } from "@/components/ui/segment";
import { isFomcPassed } from "@/lib/engine";
import { useInvictus } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/lock")({ component: LockPage });

function LockPage() {
  const store = useInvictus();
  const [confirm, setConfirm] = useState("");
  const fomc = isFomcPassed();
  const canSign = fomc && confirm.trim().toUpperCase() === "SIGN";

  return (
    <div className="space-y-10">
      <header className="max-w-2xl">
        <p className="stamp text-[11px] text-subtle">Lock file</p>
        <h1 className="font-display mt-3 text-4xl tracking-tight">
          The only document that authorises AutoInvest.
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          A briefing, an analysis, a conversation — none of these are a change
          log entry. Decision date precedes change date. Always.
        </p>
      </header>

      <blockquote className="font-display max-w-3xl border-l border-line pl-5 text-lg leading-relaxed italic">
        {store.signedAt ? SIGNED_SENTENCE_REVISED : SIGNED_SENTENCE_LOCKED}
      </blockquote>

      <section className="rounded-xl bg-surface p-5 sm:p-6">
        <p className="stamp text-[10px] text-subtle">Working pie</p>
        <div className="mt-3 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <Segment
            ariaLabel="Working pie"
            value={store.pieMode}
            onChange={(v) => store.setPieMode(v)}
            options={[
              { value: "locked", label: "12 Sep lock" },
              { value: "revised", label: "Revised preview" },
            ]}
          />
          <p className="max-w-sm text-xs leading-relaxed text-muted">
            Preview is a briefing. It does not change AutoInvest. Signature
            switches the working pie to Revised.
          </p>
        </div>
      </section>

      <section>
        <h2 className="font-display text-2xl">Four entries — {SIGN_AFTER}</h2>
        <ol className="mt-4 space-y-2">
          {LOCK_ENTRIES.map((e) => (
            <li key={e.n} className="rounded-xl bg-surface px-5 py-4">
              <p className="stamp text-[10px] text-subtle">Entry {e.n}</p>
              <p className="mt-2 text-sm text-fg">
                {e.from} → {e.to}
              </p>
              <p className="mt-1 text-sm text-muted">{e.reason}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="rounded-xl bg-inset p-5 shadow-[var(--shadow-border)] sm:p-7">
        <p className="stamp text-[11px] text-warn">
          {store.signedAt ? "Signed" : fomc ? "Ready to sign" : "Blocked until FOMC"}
        </p>
        <h2 className="font-display mt-3 text-2xl">Sign the sentence</h2>
        <p className="mt-3 max-w-prose text-sm leading-relaxed text-muted">
          {fomc
            ? `FOMC has occurred. Type SIGN to record the lock. AutoInvest changes on ${AUTOINVEST_ON} — the next calendar day — not today.`
            : `The FOMC is ${new Date(FOMC_AT).toLocaleString("en-GB", { timeZone: "Europe/London" })}. Protocol: sign after, not before. The box stays closed.`}
        </p>
        {store.signedAt ? (
          <div className="mt-5 space-y-3">
            <p className="text-sm text-earn">
              Recorded {new Date(store.signedAt).toLocaleString("en-GB")}. Working pie is Revised.
            </p>
            <Button variant="outline" onClick={store.unsign}>
              Revert to unsigned (testing)
            </Button>
          </div>
        ) : (
          <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center">
            <input
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              disabled={!fomc}
              placeholder={fomc ? "Type SIGN" : "Opens after FOMC"}
              className="h-11 max-w-xs rounded-md bg-surface px-3 text-sm tracking-[0.2em] text-fg shadow-[var(--shadow-border)] uppercase placeholder:tracking-normal placeholder:text-subtle disabled:opacity-40"
              aria-label="Type SIGN to confirm"
            />
            <Button disabled={!canSign} onClick={() => store.sign()}>
              Record lock file
            </Button>
          </div>
        )}
        <p className="font-display mt-6 text-[15px] leading-relaxed text-muted italic">{IF_THEN}</p>
      </section>

      <section>
        <h2 className="font-display text-2xl">Governance</h2>
        <ul className="mt-4 grid gap-3 sm:grid-cols-2">
          {GOVERNANCE.map((g) => (
            <li key={g.id} className="rounded-xl bg-surface px-5 py-4">
              <p className="text-sm font-medium text-fg">{g.title}</p>
              <p className="mt-2 text-sm leading-relaxed text-muted">{g.body}</p>
            </li>
          ))}
        </ul>
      </section>

      <section>
        <h2 className="font-display text-2xl">Permanently dead</h2>
        <ul className="mt-4 space-y-2">
          {PERMANENTLY_DEAD.map((d) => (
            <li key={d.id} className="flex flex-col gap-1 rounded-xl bg-surface px-5 py-4 sm:flex-row sm:items-baseline sm:gap-6">
              <Badge tone="suffer">{d.name}</Badge>
              <p className="text-sm text-muted">{d.reason}</p>
            </li>
          ))}
        </ul>
      </section>

      <p className={cn("text-xs text-subtle")}>
        Locked 12 September 2026, 16:55 BST. Master English edition. Sleep well.
      </p>
    </div>
  );
}
