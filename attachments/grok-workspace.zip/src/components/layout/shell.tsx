import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Landmark, Scale, Layers, TrendingUp, Lock } from "lucide-react";
import { RegimeMark } from "@/components/mark";
import { useHydrated } from "@/hooks/use-hydrated";
import { useInvictus } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Command", icon: Landmark },
  { to: "/decide", label: "Decide", icon: Scale },
  { to: "/lines", label: "Lines", icon: Layers },
  { to: "/path", label: "Path", icon: TrendingUp },
  { to: "/lock", label: "Lock", icon: Lock },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const signedAt = useInvictus((s) => s.signedAt);
  const pieMode = useInvictus((s) => s.pieMode);
  const hydrated = useHydrated();

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-accent focus:px-3 focus:py-2 focus:text-accent-fg"
      >
        Skip to content
      </a>
      <header className="sticky top-0 z-40 border-b border-line bg-bg/90 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-3 px-4">
          <Link to="/" className="flex items-center gap-2.5 text-fg">
            <RegimeMark className="size-6 text-accent" />
            <span className="flex flex-col leading-none">
              <span className="font-display text-[15px] tracking-tight">
                Invictus Prime
              </span>
              <span className="stamp mt-0.5 text-[9px] text-subtle">
                Decision maker
              </span>
            </span>
          </Link>
          <div className="flex items-center gap-2">
            {hydrated ? (
              <>
                <span
                  className={cn(
                    "hidden rounded-sm px-2 py-1 text-[10px] uppercase tracking-[0.14em] sm:inline",
                    signedAt ? "bg-earn/15 text-earn" : "bg-warn/15 text-warn",
                  )}
                >
                  {signedAt ? "Signed" : "Awaiting FOMC"}
                </span>
                <span className="rounded-sm bg-elevated px-2 py-1 text-[10px] uppercase tracking-[0.14em] text-muted">
                  {pieMode === "revised" ? "Revised pie" : "12 Sep lock"}
                </span>
              </>
            ) : (
              <span className="h-6 w-28 rounded-sm bg-elevated" />
            )}
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-6xl">
        <nav
          aria-label="Primary"
          className="sticky top-14 hidden h-[calc(100dvh-3.5rem)] w-48 shrink-0 flex-col gap-1 border-r border-line px-3 py-6 md:flex"
        >
          {NAV.map((item) => {
            const active =
              item.to === "/"
                ? pathname === "/"
                : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex h-11 items-center gap-3 rounded-md px-3 text-sm transition-colors duration-150",
                  active
                    ? "bg-elevated text-fg"
                    : "text-muted hover:bg-elevated/60 hover:text-fg",
                )}
              >
                <Icon className="size-4" strokeWidth={1.75} />
                {item.label}
              </Link>
            );
          })}
          <p className="mt-auto px-3 text-[10px] leading-relaxed tracking-wide text-subtle">
            16 lines. 2 sleeves.
            <br />
            4 regimes. 1 machine.
          </p>
        </nav>

        <main
          id="main"
          className="min-w-0 flex-1 px-4 pb-28 pt-6 md:px-8 md:pb-16 md:pt-8"
        >
          {children}
        </main>
      </div>

      <nav
        aria-label="Mobile"
        className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-bg/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md md:hidden"
      >
        <ul className="mx-auto grid max-w-lg grid-cols-5">
          {NAV.map((item) => {
            const active =
              item.to === "/"
                ? pathname === "/"
                : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "flex h-14 flex-col items-center justify-center gap-0.5 text-[10px] tracking-wide",
                    active ? "text-fg" : "text-subtle",
                  )}
                >
                  <Icon className="size-4" strokeWidth={1.75} />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
