export function RegimeMark({ className = "size-7" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      className={className}
      aria-hidden="true"
      fill="none"
    >
      <rect x="1.5" y="1.5" width="21" height="21" stroke="currentColor" strokeWidth="1.2" />
      <path d="M12 1.5v21M1.5 12h21" stroke="currentColor" strokeWidth="1.2" />
      <rect x="3.2" y="3.2" width="7.6" height="7.6" fill="currentColor" opacity="0.88" />
    </svg>
  );
}
