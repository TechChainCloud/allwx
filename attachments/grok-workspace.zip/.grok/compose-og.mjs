#!/usr/bin/env node
/**
 * Brand-pass compositor: exact serif lockup over the generated ink field.
 * Staged under .grok/ — never shipped by vite.
 */
import { readFileSync, writeFileSync } from "node:fs";
import { chromium } from "playwright";

const BG = "/workspace/artifacts/imagine_images/f956bb28-d1c0-4ea7ac91-8a17a4edfff8.jpg".replace(
  "e7aae84c",
  "f956bb28",
);
const BG_PATH = "/workspace/artifacts/imagine_images/f956bb28-d1c0-4ea7-ac91-8a17a4edfff8.jpg";
const FONT_REG = "/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf";
const FONT_IT = "/usr/share/fonts/truetype/liberation/LiberationSerif-Italic.ttf";
const OUT_PNG = "/workspace/.grok/og-card-raw.png";

const bgUri = `data:image/jpeg;base64,${readFileSync(BG_PATH).toString("base64")}`;
const fontReg = `data:font/ttf;base64,${readFileSync(FONT_REG).toString("base64")}`;
const fontIt = `data:font/ttf;base64,${readFileSync(FONT_IT).toString("base64")}`;

const html = `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<style>
@font-face {
  font-family: "LibSerif";
  src: url("${fontReg}") format("truetype");
  font-weight: 400;
  font-style: normal;
}
@font-face {
  font-family: "LibSerif";
  src: url("${fontIt}") format("truetype");
  font-weight: 400;
  font-style: italic;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body {
  width: 1200px;
  height: 630px;
  overflow: hidden;
  background: #0c0d0b;
  -webkit-font-smoothing: antialiased;
}
.card {
  position: relative;
  width: 1200px;
  height: 630px;
  background: #0c0d0b url("${bgUri}") center / cover no-repeat;
  display: flex;
  align-items: center;
  justify-content: center;
}
.card::before {
  content: "";
  position: absolute;
  inset: 36px;
  border: 1px solid rgba(212, 207, 195, 0.22);
  pointer-events: none;
}
.lockup {
  position: relative;
  z-index: 1;
  text-align: center;
  color: #ebe7dc;
  font-family: "LibSerif", serif;
}
h1 {
  font-weight: 400;
  font-size: 86px;
  line-height: 0.92;
  letter-spacing: 0.08em;
  color: #ebe7dc;
}
h1 .l1, h1 .l2 {
  display: block;
}
h1 .l2 {
  letter-spacing: 0.08em;
  margin-top: 0.02em;
}
.sub {
  margin-top: 26px;
  font-size: 22px;
  font-style: italic;
  letter-spacing: 0.22em;
  color: #d4cfc3;
  font-weight: 400;
}
.rule {
  width: 72px;
  height: 1px;
  background: #d4cfc3;
  opacity: 0.7;
  margin: 22px auto 18px;
}
.meta {
  font-size: 14px;
  letter-spacing: 0.18em;
  color: #d4cfc3;
  font-weight: 400;
}
.quad {
  display: grid;
  grid-template-columns: 11px 11px;
  grid-template-rows: 11px 11px;
  gap: 3px;
  width: 25px;
  margin: 26px auto 0;
}
.quad i {
  display: block;
  background: #d4cfc3;
}
.quad i:nth-child(1) { background: #ebe7dc; }
.quad i:nth-child(4) { background: #8aa37e; }
</style>
</head>
<body>
  <div class="card">
    <div class="lockup">
      <h1>
        <span class="l1">INVICTUS</span>
        <span class="l2">PRIME</span>
      </h1>
      <p class="sub">Decision Maker</p>
      <div class="rule"></div>
      <p class="meta">16 lines · 2 sleeves · 4 regimes · 1 machine</p>
      <div class="quad" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
    </div>
  </div>
  <script>
    (function matchPrimeWidth() {
      const a = document.querySelector(".l1");
      const b = document.querySelector(".l2");
      if (!a || !b) return;
      const target = a.getBoundingClientRect().width;
      let lo = 0.08, hi = 1.2;
      for (let i = 0; i < 18; i++) {
        const mid = (lo + hi) / 2;
        b.style.letterSpacing = mid + "em";
        const w = b.getBoundingClientRect().width;
        if (w < target) lo = mid; else hi = mid;
      }
      b.style.letterSpacing = ((lo + hi) / 2) + "em";
    })();
  </script>
</body>
</html>`;

writeFileSync("/workspace/.grok/og-card.html", html);

const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
const page = await browser.newPage({
  viewport: { width: 1200, height: 630 },
  deviceScaleFactor: 2,
});
await page.setContent(html, { waitUntil: "load" });
await page.evaluate(async () => {
  await document.fonts.ready;
});
await page.waitForTimeout(80);
await page.screenshot({ path: OUT_PNG, type: "png", omitBackground: false });
await browser.close();
console.log("wrote", OUT_PNG);
