import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as createRootRoute, b as require_jsx_runtime, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Layers, i as Lock, n as TrendingUp, o as Landmark, r as Scale, t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-WnV7qMiD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function RegimeMark({ className = "size-7" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		className,
		"aria-hidden": "true",
		fill: "none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "1.5",
				y: "1.5",
				width: "21",
				height: "21",
				stroke: "currentColor",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M12 1.5v21M1.5 12h21",
				stroke: "currentColor",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "3.2",
				y: "3.2",
				width: "7.6",
				height: "7.6",
				fill: "currentColor",
				opacity: "0.88"
			})
		]
	});
}
function useHydrated() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setHydrated(true), []);
	return hydrated;
}
var REGIMES = [
	{
		id: "goldilocks",
		name: "Goldilocks",
		growth: "up",
		inflation: "down",
		blurb: "Growth rising, inflation falling. The engine compounds hard.",
		response: "45% VWRP compounds. Bond sleeve appreciates. Real assets drag slightly — the acceptable cost of insurance in a good year."
	},
	{
		id: "reflation",
		name: "Reflation",
		growth: "up",
		inflation: "up",
		blurb: "Growth rising, inflation rising. Current regime as of 12 Sep 2026.",
		response: "Engine and commodity sleeve both earn. Inflation protection activates. DBMF trends the rate move. Bond sleeve drags — contained at weight."
	},
	{
		id: "stagflation",
		name: "Stagflation",
		growth: "down",
		inflation: "up",
		blurb: "Growth falling, inflation rising. Real assets absorb the blow.",
		response: "Gold and commodities at 8% each absorb. DBMF trends the equity fall. XSTR earns the overnight rate. 45% × −10% = −4.5pp, not a wipeout."
	},
	{
		id: "deflation",
		name: "Deflation",
		growth: "down",
		inflation: "down",
		blurb: "Growth falling, inflation falling. The umbrella finally earns.",
		response: "Long-bond convexity (IDTL) surges. VAGS appreciates. SGLN holds as a monetary safe haven. Bond sleeve earns its keep after years of waiting."
	}
];
function regimeFromFlags(growth, inflation) {
	if (growth === "up" && inflation === "down") return "goldilocks";
	if (growth === "up" && inflation === "up") return "reflation";
	if (growth === "down" && inflation === "up") return "stagflation";
	return "deflation";
}
var lockedLines = [
	{
		ticker: "VWRP",
		name: "Vanguard FTSE All-World UCITS ETF",
		weight: 45,
		floor: 40,
		cap: 50,
		sleeve: 1,
		job: "The Engine. Full compounding power of human productivity.",
		analogy: "The rent you collect from human civilisation. You do not manage the tenants.",
		story: "You own a small share of every factory, software company, hospital, shipping line and semiconductor fab on earth. The line goes up over decades not because markets are always rational but because humans are always productive.",
		regimes: {
			goldilocks: "earn",
			reflation: "earn",
			stagflation: "suffer",
			deflation: "suffer"
		},
		fiveYear: 11.44,
		y2022: -8.38,
		sharpe: .63,
		ter: "0.22%",
		partnersWhenSuffers: [
			"VAGS",
			"IDTL",
			"SGLN",
			"DBMF",
			"XSTR"
		],
		exposure: "equity"
	},
	{
		ticker: "ICOM",
		name: "iShares Diversified Commodity Swap UCITS ETF",
		weight: 8,
		floor: 5,
		cap: 12,
		sleeve: 1,
		job: "Inflation collector. Energy, metals, agriculture futures.",
		analogy: "The portfolio’s speedometer for the real economy.",
		story: "When credit expands, the first thing that happens is the price of oil, copper, wheat and gas going up. ICOM is not a bet on inflation — it is inflation, held as an asset. 2022: +26.6% when equities and bonds fell.",
		regimes: {
			goldilocks: "ok",
			reflation: "earn",
			stagflation: "earn",
			deflation: "suffer"
		},
		fiveYear: 12.53,
		y2022: 26.59,
		sharpe: .56,
		ter: "0.19%",
		partnersWhenSuffers: [
			"VAGS",
			"IDTL",
			"SGLN"
		],
		exposure: "real"
	},
	{
		ticker: "SGLN",
		name: "iShares Physical Gold ETC",
		weight: 8,
		floor: 5,
		cap: 12,
		sleeve: 1,
		job: "Monetary anchor. Allocated physical gold. No counterparty.",
		analogy: "The portfolio’s long memory. VWRP remembers the last decade. SGLN remembers the last century.",
		story: "Gold has been money for 5,000 years because it cannot be printed. You do not fire the fire extinguisher because it sat unused for three years. +12.6% in 2022. +48.9% in 2025.",
		regimes: {
			goldilocks: "ok",
			reflation: "ok",
			stagflation: "earn",
			deflation: "earn"
		},
		fiveYear: 19.9,
		y2022: 12.61,
		sharpe: .98,
		ter: "0.12%",
		partnersWhenSuffers: [
			"VWRP",
			"XDWI",
			"DFNS",
			"SMGB"
		],
		exposure: "real"
	},
	{
		ticker: "DBMF",
		name: "iMGP DBi Managed Futures UCITS ETF",
		weight: 4,
		floor: 1,
		cap: 6,
		sleeve: 1,
		job: "Trend follower. Earns in sustained moves, either direction.",
		analogy: "The surfer. Does not create the wave. Reads the ocean and rides whatever arrives.",
		story: "When the machine shifts quadrant the transition is violent and sustained. That is exactly when DBMF earns most. Cap 6%. +21.4% over 5 years.",
		regimes: {
			goldilocks: "ok",
			reflation: "earn",
			stagflation: "earn",
			deflation: "earn"
		},
		fiveYear: 21.29,
		y2022: null,
		sharpe: 1.4,
		ter: "0.85%",
		partnersWhenSuffers: ["VWRP", "XSTR"],
		exposure: "trend"
	},
	{
		ticker: "DFNS",
		name: "VanEck Defense UCITS ETF",
		weight: 3,
		floor: 0,
		cap: 5,
		sleeve: 1,
		job: "Geopolitical premium. Recession-proof government contracts.",
		analogy: "The geopolitical tax collector. Governments write the cheque. DFNS owns the payee.",
		story: "+22.7% / +45.3% / +54.8% in 2023–2025. Thematic satellite, cap 5%. You are not betting on war — you own the infrastructure governments pay for regardless.",
		regimes: {
			goldilocks: "ok",
			reflation: "earn",
			stagflation: "earn",
			deflation: "suffer"
		},
		fiveYear: 33.53,
		y2022: null,
		sharpe: 1.44,
		ter: "0.55%",
		partnersWhenSuffers: [
			"VWRP",
			"VAGS",
			"XDWI"
		],
		exposure: "equity"
	},
	{
		ticker: "SMGB",
		name: "VanEck Semiconductor UCITS ETF",
		weight: 2.5,
		floor: 0,
		cap: 5,
		sleeve: 1,
		job: "Picks and shovels of the digital economy.",
		analogy: "You do not pick the miner. You own the factory that supplies the picks.",
		story: "At 2.5%, a −30% year costs 75bp. A +65% year (2023) adds 163bp. The size is the risk management. Worst 2022 line: −27.23%.",
		regimes: {
			goldilocks: "earn",
			reflation: "earn",
			stagflation: "suffer",
			deflation: "suffer"
		},
		fiveYear: 33.39,
		y2022: -27.23,
		sharpe: .93,
		ter: "0.35%",
		partnersWhenSuffers: [
			"XDWH",
			"VAGS",
			"SGLN"
		],
		exposure: "equity"
	},
	{
		ticker: "XDWI",
		name: "Xtrackers MSCI World Industrials UCITS ETF",
		weight: 2,
		floor: 0,
		cap: 5,
		sleeve: 1,
		job: "Builder of everything. Capex, infrastructure, reshoring.",
		analogy: "The picks-and-shovels of the physical economy.",
		story: "5-year +11.67% — strongest satellite equity line after SMGB. Together with DFNS it layers the geopolitical capex cycle: broad industrials plus pure-play defence.",
		regimes: {
			goldilocks: "earn",
			reflation: "earn",
			stagflation: "ok",
			deflation: "suffer"
		},
		fiveYear: 11.67,
		y2022: -3.67,
		sharpe: .55,
		ter: "0.25%",
		partnersWhenSuffers: [
			"VAGS",
			"SGLN",
			"XSTR"
		],
		exposure: "equity",
		notes: "AUM £0.99bn — smaller than ideal. Watch for AUM growth."
	},
	{
		ticker: "XDWH",
		name: "Xtrackers MSCI World Health Care UCITS ETF",
		weight: 2,
		floor: 0,
		cap: 5,
		sleeve: 1,
		job: "The night shift doctor. Defensive equity. On probation.",
		analogy: "The doctor’s surgery in the town. Never hungry in a bust. Does not get rich in a boom.",
		story: "+7.8% in 2022 when VWRP fell −8.4%. Weakest 5-year satellite Sharpe at 0.17. Review September 2029: did it earn its keep in the next cycle?",
		regimes: {
			goldilocks: "ok",
			reflation: "ok",
			stagflation: "earn",
			deflation: "earn"
		},
		fiveYear: 4.76,
		y2022: 7.8,
		sharpe: .17,
		ter: "0.25%",
		partnersWhenSuffers: ["VWRP", "SMGB"],
		exposure: "equity",
		probation: "Review September 2029."
	},
	{
		ticker: "COPA",
		name: "WisdomTree Copper ETC",
		weight: 2,
		floor: 0,
		cap: 5,
		sleeve: 1,
		job: "The metal of electrification. Copper price, not miners.",
		analogy: "Every EV, turbine and data centre needs copper. There is not enough of it.",
		story: "Physical copper via futures — not mining companies. Structural demand, constrained supply. New mines take 10–15 years.",
		regimes: {
			goldilocks: "earn",
			reflation: "earn",
			stagflation: "ok",
			deflation: "suffer"
		},
		fiveYear: 8.05,
		y2022: -3.69,
		sharpe: .2,
		ter: "0.49%",
		partnersWhenSuffers: [
			"VAGS",
			"IDTL",
			"SGLN"
		],
		exposure: "real"
	},
	{
		ticker: "ITPS",
		name: "iShares USD TIPS UCITS ETF",
		weight: 6,
		floor: 4,
		cap: 12,
		sleeve: 2,
		job: "US CPI protection. A structural hedge, not a bet.",
		analogy: "The lease with a rent review clause.",
		story: "Ordinary bonds have a fixed coupon. Inflation robs you slowly and legally. TIPS principal adjusts with US CPI. You are always made whole in real terms.",
		regimes: {
			goldilocks: "ok",
			reflation: "earn",
			stagflation: "earn",
			deflation: "suffer"
		},
		fiveYear: .32,
		y2022: -.79,
		sharpe: -.34,
		ter: "0.10%",
		partnersWhenSuffers: [
			"VAGS",
			"IDTL",
			"IGLS",
			"SGLN"
		],
		exposure: "linker"
	},
	{
		ticker: "VAGS",
		name: "Vanguard Global Aggregate Bond UCITS ETF",
		weight: 6,
		floor: 3,
		cap: 10,
		sleeve: 2,
		job: "Nominal ballast. Deflation insurance. Most misunderstood line.",
		analogy: "Fire insurance on the house. Useless in a drought. Essential in a flood.",
		story: "−0.86% over 5 years is the cost of holding the umbrella through the worst bond market in 40 years. That is not failure. That is the umbrella getting wet in the rain it was designed for.",
		regimes: {
			goldilocks: "earn",
			reflation: "suffer",
			stagflation: "suffer",
			deflation: "earn"
		},
		fiveYear: -.86,
		y2022: -13.23,
		sharpe: -.84,
		ter: "0.08%",
		partnersWhenSuffers: [
			"ICOM",
			"ITPS",
			"INXG",
			"XSTR",
			"DBMF"
		],
		exposure: "nominal"
	},
	{
		ticker: "XSTR",
		name: "Xtrackers II GBP Overnight Rate Swap UCITS ETF",
		weight: 5,
		floor: 2,
		cap: 8,
		sleeve: 2,
		job: "Walk-back reserve. SONIA overnight. Never goes down.",
		analogy: "The cash in the tin under the bed. The quiet room. The general’s reserve.",
		story: "Trigger: PMI < 50 AND curve inverted. All contributions route here. Never negative in nominal terms. FLOT’s +13.9% GBP in 2022 was FX, not carry. XSTR is not replaced at £1,053 NAV.",
		regimes: {
			goldilocks: "earn",
			reflation: "earn",
			stagflation: "earn",
			deflation: "earn"
		},
		fiveYear: 3.53,
		y2022: 1.25,
		sharpe: .27,
		ter: "0.10%",
		partnersWhenSuffers: [],
		exposure: "cash",
		notes: "AUM £194.6M — above the £150M watch floor. Monitor annually."
	},
	{
		ticker: "IDTL",
		name: "iShares USD Treasury Bond 20+yr UCITS ETF",
		weight: 2,
		floor: 0,
		cap: 6,
		sleeve: 2,
		job: "Convexity stub. US 20+ Treasuries. A stub, not a position.",
		analogy: "A compressed spring. Every rate hike winds it tighter. The release is the payoff.",
		story: "GT30 5.355% — 4.5bp from the 5.40% duration-hit flag. If GT30 crosses 5.40%, IDTL loses ~5% — 10bp of portfolio impact. Do not sell. The spring is being compressed further. US Treasuries, not UK gilts.",
		regimes: {
			goldilocks: "earn",
			reflation: "suffer",
			stagflation: "suffer",
			deflation: "earn"
		},
		fiveYear: -7.73,
		y2022: -19.45,
		sharpe: -.71,
		ter: "0.07%",
		partnersWhenSuffers: [
			"ICOM",
			"ITPS",
			"XSTR",
			"DBMF"
		],
		exposure: "nominal"
	},
	{
		ticker: "INXG",
		name: "iShares Index-Linked Gilts UCITS ETF",
		weight: 2,
		floor: 1,
		cap: 5,
		sleeve: 2,
		job: "UK inflation witness. RPI linkers. UK CPI is not US CPI.",
		analogy: "The London thermometer. ITPS is New York. A GBP investor needs both readings.",
		story: "5-year −9.99% — worst in the book. 2022 −34.2% at 2% weight cost 68bp. Extreme duration. The 2% weight is sized to capture the payoff without letting duration dominate. A stub, not a position.",
		regimes: {
			goldilocks: "ok",
			reflation: "earn",
			stagflation: "earn",
			deflation: "suffer"
		},
		fiveYear: -9.99,
		y2022: -34.2,
		sharpe: null,
		ter: "0.10%",
		partnersWhenSuffers: [
			"VAGS",
			"IDTL",
			"IGLS",
			"SGLN"
		],
		exposure: "linker",
		notes: "AUM £0.44bn — smallest in the book. If AUM falls below £200M, begin transition planning."
	},
	{
		ticker: "IGLS",
		name: "iShares UK Gilts 0–5yr UCITS ETF",
		weight: 1.5,
		floor: 0,
		cap: 4,
		sleeve: 2,
		job: "Short gilt carry. Carry, not duration.",
		analogy: "A savings account with a government guarantee. The most boring line. That is a feature.",
		story: "0–5 year gilts. Closest to Bank of England policy rate. TER 0.07% — joint cheapest in the book. Together with XSTR they form a short-end sterling ladder.",
		regimes: {
			goldilocks: "earn",
			reflation: "earn",
			stagflation: "earn",
			deflation: "earn"
		},
		fiveYear: 1.4,
		y2022: -4.22,
		sharpe: -.69,
		ter: "0.07%",
		partnersWhenSuffers: ["XSTR"],
		exposure: "nominal"
	},
	{
		ticker: "URNG",
		name: "Global X Uranium UCITS ETF",
		weight: 1,
		floor: 0,
		cap: 3,
		sleeve: 2,
		job: "Nuclear, contained. A 1% option on the energy transition.",
		analogy: "Sized like an option — small premium, large optional payoff, contained if it fails.",
		story: "+31% / +2% / +51% in 2023–2025. Lost −14% in 2022. At 1%, both outcomes are manageable.",
		regimes: {
			goldilocks: "ok",
			reflation: "earn",
			stagflation: "earn",
			deflation: "ok"
		},
		fiveYear: 15.4,
		y2022: null,
		sharpe: null,
		ter: "0.65%",
		partnersWhenSuffers: [
			"VWRP",
			"SGLN",
			"XSTR"
		],
		exposure: "equity"
	}
];
var xaix = {
	ticker: "XAIX",
	name: "Xtrackers AI & Big Data UCITS ETF",
	weight: 2,
	floor: 0,
	cap: 5,
	sleeve: 1,
	job: "Goldilocks / Reflation thematic. Best-return satellite confirmed.",
	analogy: "The infrastructure of the next productivity wave — models, data, compute.",
	story: "XDWH retired. XAIX confirmed at 2%. 5-year +34.35%, Sharpe 1.40. Weakest satellite replaced by the strongest available thematic with a clear job.",
	regimes: {
		goldilocks: "earn",
		reflation: "earn",
		stagflation: "ok",
		deflation: "suffer"
	},
	fiveYear: 34.35,
	y2022: null,
	sharpe: 1.4,
	ter: "0.35%",
	partnersWhenSuffers: [
		"VAGS",
		"SGLN",
		"XSTR"
	],
	exposure: "equity"
};
var nucl = {
	ticker: "NUCL",
	name: "VanEck Uranium & Nuclear Technologies UCITS ETF",
	weight: 2.5,
	floor: 0,
	cap: 5,
	sleeve: 1,
	job: "Full nuclear economy. Energy transition, contained at satellite size.",
	analogy: "The long option on zero-carbon baseload — now the whole fuel-to-reactor chain.",
	story: "URNG retired. NUCL raised to 2.5%. 3Y+ live history cleared. 5-year +27.76%, Sharpe 0.72. +19.8% / +31.7% / +51.5% in 2023–2025.",
	regimes: {
		goldilocks: "ok",
		reflation: "earn",
		stagflation: "earn",
		deflation: "ok"
	},
	fiveYear: 27.76,
	y2022: null,
	sharpe: .72,
	ter: "0.55%",
	partnersWhenSuffers: [
		"VWRP",
		"SGLN",
		"XSTR"
	],
	exposure: "equity"
};
var tip5 = {
	ticker: "TIP5",
	name: "iShares USD TIPS 0–5yr UCITS ETF",
	weight: 2,
	floor: 0,
	cap: 5,
	sleeve: 2,
	job: "Short-duration US inflation. Duration risk eliminated.",
	analogy: "The rent review clause without the 30-year spring.",
	story: "INXG retired. TIP5 enters at 2.0%. 2022: +8.97% vs INXG −34.27%. Short-duration TIPS keep the inflation proof and drop the gilt-crisis duration.",
	regimes: {
		goldilocks: "ok",
		reflation: "earn",
		stagflation: "earn",
		deflation: "ok"
	},
	fiveYear: 3.4,
	y2022: 8.97,
	sharpe: .02,
	ter: "0.10%",
	partnersWhenSuffers: [
		"VAGS",
		"IDTL",
		"SGLN"
	],
	exposure: "linker"
};
function replaceTicker(lines, from, to) {
	return lines.map((l) => l.ticker === from ? to : l);
}
var LOCKED_PIE = lockedLines;
var REVISED_PIE = replaceTicker(replaceTicker(replaceTicker(lockedLines, "XDWH", xaix).map((l) => l.ticker === "SMGB" ? {
	...l,
	weight: 1,
	cap: 3,
	notes: "Trimmed 2.5% → 1.0%. Semiconductor exposure retained via VWRP look-through."
} : l.ticker === "URNG" ? nucl : l), "INXG", tip5), "URNG", nucl).map((l) => {
	if (l.ticker === "SMGB") return {
		...l,
		partnersWhenSuffers: [
			"XAIX",
			"VAGS",
			"SGLN"
		]
	};
	if (l.ticker === "VAGS") return {
		...l,
		partnersWhenSuffers: [
			"ICOM",
			"ITPS",
			"TIP5",
			"XSTR",
			"DBMF"
		]
	};
	if (l.ticker === "ITPS") return {
		...l,
		partnersWhenSuffers: [
			"VAGS",
			"IDTL",
			"IGLS",
			"SGLN"
		]
	};
	return l;
});
var FOMC_AT = "2026-09-16T19:00:00+01:00";
var SIGN_AFTER = "16 September 2026 FOMC";
var AUTOINVEST_ON = "17 September 2026";
var SIGNED_SENTENCE_LOCKED = "Engine 45%, cap 50%. ICOM 8%, SGLN 8%. Look-through equity ~57%. Planning drawdown 30–35%. No sales. Signed after 16 September 2026 FOMC.";
var SIGNED_SENTENCE_REVISED = "Engine 45%, cap 50%. ICOM 8%, SGLN 8%. SMGB trimmed to 1%. NUCL raised to 2.5%. XDWH retired, XAIX at 2%. URNG retired. INXG retired, TIP5 at 2%. Look-through equity ~57%. Planning drawdown 30–35%. 2022 stress-test −2.11%. No sales. No FLOT before £3,000 NAV, no VHYL before £5,000 NAV. Signed after 16 September 2026 FOMC.";
var IF_THEN = "If the machine always travels through all four quadrants, then no line is sold because the current quadrant is punishing it — contributions on the 3rd do the work; the signed sentence stays the hand.";
var FARMER = "A farmer does not know what the weather will bring. So he plants wheat for the sun, builds a greenhouse for the cold, installs irrigation for the drought, and keeps a barn full of hay for the flood. He does not earn maximum profit in any single year. But he never loses the farm.";
var FARMER_MAP = {
	VWRP: "the wheat — the engine that feeds everything",
	SGLN: "the barn — the long memory that survives every reset",
	ICOM: "the irrigation — the real economy running hot",
	VAGS: "the greenhouse — cold-weather insurance nobody wants until winter",
	IDTL: "the greenhouse spring — convexity when the freeze arrives",
	ITPS: "the rent review clause — inflation proof written into the lease",
	INXG: "the London rent review — UK inflation is not US inflation",
	TIP5: "the short rent review — inflation proof without the duration",
	DBMF: "the farmer reading the weather and adjusting the hedges",
	XSTR: "the cash in the tin under the bed — the reserve that funds the next season"
};
var GOVERNANCE = [
	{
		id: "no-sales",
		title: "No selling inside the ISA",
		body: "Contributions are the only rebalancing tool. Every disposal is a compounding engine switched off."
	},
	{
		id: "lock-file",
		title: "Lock file authorises AutoInvest",
		body: "A briefing, an analysis, a conversation — none of these are a change log entry."
	},
	{
		id: "dates",
		title: "Decision date precedes change date",
		body: "Always. Sign on 16 September. Change AutoInvest on 17 September. Not before."
	},
	{
		id: "walk-back",
		title: "Walk-back trigger",
		body: "PMI < 50 AND 2s10s inverted → all contributions route to XSTR. Satellites receive zero."
	},
	{
		id: "vwrp-band",
		title: "VWRP floor 40%, cap 50%",
		body: "Below 40% → next contribution to VWRP. Above 50% → stop contributing to VWRP."
	},
	{
		id: "satellite",
		title: "No satellite above 5%",
		body: "No Sleeve 1 line above its cap. No 17th personality."
	},
	{
		id: "gates",
		title: "Size gates hold",
		body: "FLOT at £3,000+ NAV. VHYL at £5,000+ NAV. ROLL at £10,000+ NAV."
	}
];
var LOCK_ENTRIES = [
	{
		n: 1,
		from: "XDWH LN",
		to: "XAIX LN at 2%",
		reason: "Weakest satellite retired. Best-return satellite confirmed."
	},
	{
		n: 2,
		from: "URNG LN",
		to: "NUCL LN at 2.5%",
		reason: "Full nuclear economy. 3Y+ live history cleared."
	},
	{
		n: 3,
		from: "SMGB LN 2.5%",
		to: "SMGB LN 1.0%",
		reason: "Worst 2022 line in the portfolio: −27.23%. Semiconductor exposure retained via VWRP look-through."
	},
	{
		n: 4,
		from: "INXG LN",
		to: "TIP5 LN at 2.0%",
		reason: "Long-duration UK linker retired. Short-duration US TIPS replaces it. Duration risk eliminated."
	}
];
var PERMANENTLY_DEAD = [
	{
		id: "d-prime",
		name: "D-Prime",
		reason: "Arithmetic was wrong. 2022 ≈ −1.04%, not +1.35%."
	},
	{
		id: "sectors",
		name: "IITU / WNRG / XDWF",
		reason: "Sector bets, not All Weather lines."
	},
	{
		id: "flot",
		name: "FLOT replacing XSTR at £1,053 NAV",
		reason: "FLOT’s +13.9% GBP in 2022 was GBP/USD depreciation, not carry."
	},
	{
		id: "gold-scale",
		name: "Scaling ICOM/SGLN then doubling gold",
		reason: "Construction error, not research. Both lines stand at 8%."
	},
	{
		id: "labels",
		name: "Wrong fund labels",
		reason: "ITPS is US TIPS, IDTL is US Treasuries, SMGB is semiconductors, XSTR is SONIA."
	},
	{
		id: "alts",
		name: "Crypto, REITs, IWQU, second BCOM",
		reason: "Rejected for documented reasons."
	},
	{
		id: "eight",
		name: "8% as a planning return",
		reason: "Retired. Stress base 5%. Bayesian 7.5%."
	}
];
var SIZE_GATES = [
	{
		id: "FLOT",
		name: "FLOT LN",
		threshold: 3e3,
		replaces: "XSTR",
		note: "Case rests on carry differential in normal years, not a one-year FX windfall."
	},
	{
		id: "VHYL",
		name: "VHYL LN",
		threshold: 5e3,
		replaces: null,
		note: "Income satellite. Not before £5,000 NAV."
	},
	{
		id: "ROLL",
		name: "ROLL LN",
		threshold: 1e4,
		replaces: null,
		note: "Not before £10,000 NAV."
	}
];
var STATS_LOCKED = {
	mean: 9.54,
	vol: 6.9,
	best: {
		year: 2025,
		value: 15.64
	},
	worst: {
		year: 2022,
		value: -3.69
	},
	positiveYears: "6 of 7",
	neverBelowCash: true,
	drawdownPlan: "30–35%",
	equityLookThrough: 57,
	stress2022: -3.69
};
var STATS_REVISED = {
	mean: 8.18,
	vol: 6.06,
	best: {
		year: 2024,
		value: 15.62
	},
	worst: {
		year: 2018,
		value: -2.41
	},
	positiveYears: "7 of 9",
	neverBelowCash: true,
	drawdownPlan: "30–35%",
	equityLookThrough: 57,
	stress2022: -2.11
};
var YEARLY_REVISED = [
	{
		year: 2017,
		ret: 6.34,
		driver: "VWRP +13.2%, COPA +16.6% offset by ITPS/VAGS drag"
	},
	{
		year: 2018,
		ret: -2.41,
		driver: "VWRP −4.1%, COPA −17.4%, XDWI −10.3% — broad sell-off"
	},
	{
		year: 2019,
		ret: 13.01,
		driver: "VWRP +21.6%, SGLN +14.0%, IDTL +10.5%"
	},
	{
		year: 2020,
		ret: 9.52,
		driver: "VWRP +12.7%, SGLN +20.1%, IDTL +14.6% — flight to safety worked"
	},
	{
		year: 2021,
		ret: 11.17,
		driver: "VWRP +19.4%, COPA +26.8%, SMGB +42.0%"
	},
	{
		year: 2022,
		ret: -2.11,
		driver: "ICOM +26.6%, SGLN +12.6%, TIP5 +9.0% absorbed the rate shock"
	},
	{
		year: 2023,
		ret: 10.39,
		driver: "VWRP +15.6%, DFNS +22.7%, NUCL +19.8%"
	},
	{
		year: 2024,
		ret: 15.62,
		driver: "VWRP +19.5%, SGLN +28.7%, DFNS +45.3%, NUCL +31.7%"
	},
	{
		year: 2025,
		ret: 12.09,
		driver: "DFNS +54.8%, NUCL +51.5%, SMGB +37.0%, DBMF +15.1%"
	}
];
var PLAN_PATHS = {
	stress: {
		rate: 5,
		label: "Stress base — plan around this",
		at1600: {
			5: 107436,
			10: 243211,
			15: 416498,
			20: 637660,
			25: 919926,
			30: 1280177
		}
	},
	bayesian: {
		rate: 7.5,
		label: "Bayesian central — working assumption",
		at1600: {
			5: 113033,
			10: 273794,
			15: 504588,
			20: 835923,
			25: 1311596,
			30: 1994487
		}
	},
	historical: {
		rate: 8.18,
		label: "Historical 8.18% — 9-year verified. Do not plan around it.",
		at1600: {
			5: 114604,
			10: 282842,
			15: 532107,
			20: 901420,
			25: 1448600,
			30: 2259309
		}
	}
};
var MILESTONE_1M = {
	stress: {
		"200": "Never in 30Y (£164K)",
		"1600": "Year ~28",
		"1667": "Year ~27"
	},
	bayesian: {
		"200": "Never in 30Y (£257K)",
		"1600": "Year ~22",
		"1667": "Year ~21"
	},
	historical: {
		"200": "Never in 30Y (£292K)",
		"1600": "Year ~22",
		"1667": "Year ~21"
	}
};
var STRESS_SCENARIOS = [
	{
		id: "rate",
		name: "Rate shock (2022-style)",
		impact: "−2.11% revised / −3.69% locked",
		cushion: "ICOM +26.6%, SGLN +12.6%, TIP5 +9.0%"
	},
	{
		id: "equity",
		name: "Equity crash (2018-style)",
		impact: "−2.41% revised",
		cushion: "ITPS +4.5%, SGLN +4.7%, XSTR +0.4%"
	},
	{
		id: "deflation",
		name: "Full deflation (2008-style)",
		impact: "Net est. −8 to −12%",
		cushion: "Defensive sleeve activates fully. The only double-digit loss scenario."
	},
	{
		id: "gold",
		name: "Gold crashes −20%",
		impact: "SGLN 8% × −20% = −1.60pp",
		cushion: "ICOM, VWRP, DFNS likely positive in the same environment"
	},
	{
		id: "commodity",
		name: "Commodity rout −30%",
		impact: "ICOM + COPA = −3.0pp",
		cushion: "IDTL, VAGS, SGLN likely rally in a deflation scenario"
	}
];
var COOPERATION = [
	{
		suffers: "VWRP (equity crash)",
		earns: "VAGS, IDTL, SGLN, DBMF, XSTR"
	},
	{
		suffers: "VAGS + IDTL (rate hike)",
		earns: "ICOM, ITPS, INXG/TIP5, XSTR, DBMF"
	},
	{
		suffers: "ICOM (commodity crash)",
		earns: "VAGS, IDTL, SGLN"
	},
	{
		suffers: "SGLN (Goldilocks, risk-on)",
		earns: "VWRP, XDWI, DFNS, SMGB"
	},
	{
		suffers: "ITPS + linkers (deflation)",
		earns: "VAGS, IDTL, IGLS, SGLN"
	},
	{
		suffers: "SMGB (tech crash)",
		earns: "XDWH/XAIX, VAGS, SGLN"
	},
	{
		suffers: "DFNS (peace dividend)",
		earns: "VWRP, VAGS, XDWI"
	},
	{
		suffers: "URNG/NUCL (uranium bear)",
		earns: "Everything else — contained at weight"
	}
];
function targetWeights(pie) {
	return Object.fromEntries(pie.map((l) => [l.ticker, l.weight]));
}
var DEFAULT_NAV = 1053;
var DEFAULT_CONTRIBUTION = 1600;
var DEFAULT_GT30 = 5.355;
var IDTL_FLAG = 5.4;
function weightsFor(mode) {
	return targetWeights(mode === "revised" ? REVISED_PIE : LOCKED_PIE);
}
var useInvictus = create()(persist((set, get) => ({
	growth: "up",
	inflation: "up",
	pmi: 52,
	curveInverted: false,
	nav: DEFAULT_NAV,
	contribution: DEFAULT_CONTRIBUTION,
	gt30: DEFAULT_GT30,
	signedAt: null,
	pieMode: "locked",
	weights: weightsFor("locked"),
	setGrowth: (growth) => set({ growth }),
	setInflation: (inflation) => set({ inflation }),
	setPmi: (pmi) => set({ pmi: Math.round(pmi * 10) / 10 }),
	setCurveInverted: (curveInverted) => set({ curveInverted }),
	setNav: (nav) => set({ nav }),
	setContribution: (contribution) => set({ contribution }),
	setGt30: (gt30) => set({ gt30 }),
	setWeight: (ticker, value) => set({ weights: {
		...get().weights,
		[ticker]: value
	} }),
	resetWeights: () => set({ weights: weightsFor(get().pieMode) }),
	sign: () => set({
		signedAt: (/* @__PURE__ */ new Date()).toISOString(),
		pieMode: "revised",
		weights: weightsFor("revised")
	}),
	unsign: () => set({
		signedAt: null,
		pieMode: "locked",
		weights: weightsFor("locked")
	}),
	setPieMode: (pieMode) => set({
		pieMode,
		weights: weightsFor(pieMode)
	})
}), { name: "invictus-prime-v1" }));
function selectPie(mode) {
	return mode === "revised" ? REVISED_PIE : LOCKED_PIE;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatPct(n, digits = 2) {
	return `${n > 0 ? "+" : ""}${n.toFixed(digits)}%`;
}
function formatGbp(n, digits = 0) {
	return new Intl.NumberFormat("en-GB", {
		style: "currency",
		currency: "GBP",
		maximumFractionDigits: digits,
		minimumFractionDigits: digits
	}).format(n);
}
function formatCompactGbp(n) {
	if (Math.abs(n) >= 1e6) return `£${(n / 1e6).toFixed(2)}M`;
	if (Math.abs(n) >= 1e3) return `£${Math.round(n / 1e3)}k`;
	return formatGbp(n);
}
var NAV = [
	{
		to: "/",
		label: "Command",
		icon: Landmark
	},
	{
		to: "/decide",
		label: "Decide",
		icon: Scale
	},
	{
		to: "/lines",
		label: "Lines",
		icon: Layers
	},
	{
		to: "/path",
		label: "Path",
		icon: TrendingUp
	},
	{
		to: "/lock",
		label: "Lock",
		icon: Lock
	}
];
function Shell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const signedAt = useInvictus((s) => s.signedAt);
	const pieMode = useInvictus((s) => s.pieMode);
	const hydrated = useHydrated();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#main",
				className: "sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-accent focus:px-3 focus:py-2 focus:text-accent-fg",
				children: "Skip to content"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-line bg-bg/90 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-14 max-w-6xl items-center justify-between gap-3 px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-2.5 text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RegimeMark, { className: "size-6 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex flex-col leading-none",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-[15px] tracking-tight",
								children: "Invictus Prime"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "stamp mt-0.5 text-[9px] text-subtle",
								children: "Decision maker"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-2",
						children: hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("hidden rounded-sm px-2 py-1 text-[10px] uppercase tracking-[0.14em] sm:inline", signedAt ? "bg-earn/15 text-earn" : "bg-warn/15 text-warn"),
							children: signedAt ? "Signed" : "Awaiting FOMC"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-sm bg-elevated px-2 py-1 text-[10px] uppercase tracking-[0.14em] text-muted",
							children: pieMode === "revised" ? "Revised pie" : "12 Sep lock"
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-6 w-28 rounded-sm bg-elevated" })
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					"aria-label": "Primary",
					className: "sticky top-14 hidden h-[calc(100dvh-3.5rem)] w-48 shrink-0 flex-col gap-1 border-r border-line px-3 py-6 md:flex",
					children: [NAV.map((item) => {
						const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex h-11 items-center gap-3 rounded-md px-3 text-sm transition-colors duration-150", active ? "bg-elevated text-fg" : "text-muted hover:bg-elevated/60 hover:text-fg"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-4",
								strokeWidth: 1.75
							}), item.label]
						}, item.to);
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-auto px-3 text-[10px] leading-relaxed tracking-wide text-subtle",
						children: [
							"16 lines. 2 sleeves.",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"4 regimes. 1 machine."
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					id: "main",
					className: "min-w-0 flex-1 px-4 pb-28 pt-6 md:px-8 md:pb-16 md:pt-8",
					children
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				"aria-label": "Mobile",
				className: "fixed inset-x-0 bottom-0 z-40 border-t border-line bg-bg/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mx-auto grid max-w-lg grid-cols-5",
					children: NAV.map((item) => {
						const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex h-14 flex-col items-center justify-center gap-0.5 text-[10px] tracking-wide", active ? "text-fg" : "text-subtle"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-4",
								strokeWidth: 1.75
							}), item.label]
						}) }, item.to);
					})
				})
			})
		]
	});
}
var styles_default = "/assets/styles-BDI4Kat8.css";
var APP_NAME = "Invictus Prime";
var Route$5 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Invictus Prime decision maker. 16 lines. 2 sleeves. 4 regimes. 1 machine. The signed sentence stays the hand."
			},
			{
				name: "theme-color",
				content: "#0c0d0b"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Newsreader:ital,opsz,wght@0,6..72,400;0,6..72,500;0,6..72,600;1,6..72,400;1,6..72,500&family=Outfit:wght@400;500;600;700&display=swap"
			}
		]
	}),
	component: RootDocument,
	notFoundComponent: NotFound
});
function RootDocument() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-bg text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-20 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "stamp text-[11px] text-subtle",
				children: "Missing"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display mt-3 text-3xl",
				children: "This page is not in the pie."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "No 17th route."
			})
		]
	});
}
var $$splitComponentImporter$4 = () => import("./routes-S1O6-SM2.mjs");
var Route$4 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./decide-CNdJUW7V.mjs");
var Route$3 = createFileRoute("/decide")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./lines-DwM5Rz4J.mjs");
var Route$2 = createFileRoute("/lines")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./lock-DSmTHuLx.mjs");
var Route$1 = createFileRoute("/lock")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./path-CgHLfwYG.mjs");
var Route = createFileRoute("/path")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$4.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$5
	}),
	DecideRoute: Route$3.update({
		id: "/decide",
		path: "/decide",
		getParentRoute: () => Route$5
	}),
	LinesRoute: Route$2.update({
		id: "/lines",
		path: "/lines",
		getParentRoute: () => Route$5
	}),
	LockRoute: Route$1.update({
		id: "/lock",
		path: "/lock",
		getParentRoute: () => Route$5
	}),
	PathRoute: Route.update({
		id: "/path",
		path: "/path",
		getParentRoute: () => Route$5
	})
};
var routeTree = Route$5._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent,
		defaultPreload: "intent",
		scrollRestoration: true
	});
}
//#endregion
export { YEARLY_REVISED as A, SIGNED_SENTENCE_LOCKED as C, STATS_LOCKED as D, SIZE_GATES as E, useHydrated as M, STATS_REVISED as O, REVISED_PIE as S, SIGN_AFTER as T, LOCK_ENTRIES as _, formatPct as a, PLAN_PATHS as b, AUTOINVEST_ON as c, FARMER_MAP as d, FOMC_AT as f, LOCKED_PIE as g, IF_THEN as h, formatGbp as i, regimeFromFlags as j, STRESS_SCENARIOS as k, COOPERATION as l, IDTL_FLAG as m, cn as n, selectPie as o, GOVERNANCE as p, formatCompactGbp as r, useInvictus as s, router_exports as t, FARMER as u, MILESTONE_1M as v, SIGNED_SENTENCE_REVISED as w, REGIMES as x, PERMANENTLY_DEAD as y };
