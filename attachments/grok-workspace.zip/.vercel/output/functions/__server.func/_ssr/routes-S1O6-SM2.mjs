import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as SIGNED_SENTENCE_LOCKED, M as useHydrated, f as FOMC_AT, h as IF_THEN, j as regimeFromFlags, n as cn, o as selectPie, s as useInvictus, u as FARMER, w as SIGNED_SENTENCE_REVISED, x as REGIMES } from "./router-WnV7qMiD.mjs";
import { t as Badge } from "./badge-BsNt2dFM.mjs";
import { n as earners, o as routeContribution, p as walkBackActive, r as idtlFlag, s as sufferers, t as Button } from "./engine-BIGKsWsh.mjs";
import { t as Segment } from "./segment-hSgKujC5.mjs";
import { t as VerdictCard } from "./verdict-card-DBxXqytc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-S1O6-SM2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RegimeBoard({ active, onSelect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 flex justify-between px-1 text-[10px] uppercase tracking-[0.16em] text-subtle",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Inflation falling" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Inflation rising" })]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-1 rounded-xl bg-surface p-1",
		children: [
			"goldilocks",
			"reflation",
			"deflation",
			"stagflation"
		].map((id, i) => {
			const r = REGIMES.find((x) => x.id === id);
			const on = id === active;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onSelect(id),
				className: cn("relative min-h-28 rounded-lg px-4 py-4 text-left transition-colors duration-150", on ? "bg-accent text-accent-fg" : "bg-inset text-fg hover:bg-elevated"),
				children: [
					i === 0 || i === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("absolute right-3 top-3 text-[9px] uppercase tracking-[0.14em]", on ? "text-accent-fg/70" : "text-subtle"),
						children: "Growth rising"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("absolute right-3 top-3 text-[9px] uppercase tracking-[0.14em]", on ? "text-accent-fg/70" : "text-subtle"),
						children: "Growth falling"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl leading-tight",
						children: r.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("mt-2 max-w-[26ch] text-xs leading-relaxed", on ? "text-accent-fg/80" : "text-muted"),
						children: r.blurb
					})
				]
			}, id);
		})
	})] });
}
function fomcCopy(now) {
	const ms = new Date(FOMC_AT).getTime() - now.getTime();
	if (ms <= 0) return {
		title: "FOMC has occurred",
		sub: "Sign the sentence. Write the lock file. AutoInvest the next calendar day."
	};
	const hours = Math.floor(ms / 36e5);
	const days = Math.floor(hours / 24);
	const remH = hours % 24;
	return {
		title: days > 0 ? `${days}d ${remH}h to FOMC` : `${hours}h to FOMC`,
		sub: "16 September 2026, 19:00 BST. Sign after. Change AutoInvest on the 17th. Not before."
	};
}
function idtlWatchCopy(gt30) {
	return `GT30 is ${(Math.round((5.4 - gt30) * 1e3) / 10).toFixed(1)}bp from the 5.40% flag. At 2% weight a 5% IDTL drop is 10bp of the pie. Rounding error.`;
}
function CommandPage() {
	const hydrated = useHydrated();
	const store = useInvictus();
	const pie = selectPie(store.pieMode);
	const regime = regimeFromFlags(store.growth, store.inflation);
	const meta = REGIMES.find((r) => r.id === regime);
	const routing = (0, import_react.useMemo)(() => routeContribution(pie, store), [
		pie,
		store.pmi,
		store.curveInverted,
		store.contribution,
		store.weights,
		store.growth,
		store.inflation,
		store.nav,
		store.gt30,
		store.signedAt,
		store.pieMode
	]);
	const clock = fomcCopy(hydrated ? /* @__PURE__ */ new Date() : /* @__PURE__ */ new Date("2026-09-14T00:34:00+01:00"));
	const wb = walkBackActive(store.pmi, store.curveInverted);
	const earn = earners(pie, regime);
	const hurt = sufferers(pie, regime);
	const sentence = store.pieMode === "revised" ? SIGNED_SENTENCE_REVISED : SIGNED_SENTENCE_LOCKED;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rounded-xl bg-surface p-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 rounded-lg bg-inset px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "stamp text-[10px] text-warn",
						children: clock.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-sm leading-relaxed text-muted",
						children: clock.sub
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/lock",
							children: "Open lock file"
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "stamp text-[11px] text-subtle",
						children: "Command"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-3 text-4xl leading-[1.1] tracking-tight sm:text-[2.75rem]",
						children: "The machine does not need to know which regime comes next."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm leading-relaxed text-muted",
						children: "Something meaningful is working in every condition. The lines that fall are offset by the lines that rise. Contributions on the 3rd do the work. The signed sentence stays the hand."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "font-display max-w-3xl border-l border-line pl-5 text-lg leading-relaxed text-fg italic sm:text-xl",
				children: sentence
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-8 lg:grid-cols-[1.15fr_0.85fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
							ariaLabel: "Growth",
							value: store.growth,
							onChange: store.setGrowth,
							options: [{
								value: "up",
								label: "Growth ↑"
							}, {
								value: "down",
								label: "Growth ↓"
							}]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
							ariaLabel: "Inflation",
							value: store.inflation,
							onChange: store.setInflation,
							options: [{
								value: "up",
								label: "Inflation ↑"
							}, {
								value: "down",
								label: "Inflation ↓"
							}]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RegimeBoard, {
						active: regime,
						onSelect: (id) => {
							const r = REGIMES.find((x) => x.id === id);
							store.setGrowth(r.growth);
							store.setInflation(r.inflation);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm leading-relaxed text-muted",
						children: meta.response
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-surface p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "stamp text-[10px] text-subtle",
								children: "Who earns"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 flex flex-wrap gap-1.5",
								children: earn.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "earn",
									children: l.ticker
								}, l.ticker))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "stamp mt-5 text-[10px] text-subtle",
								children: "Who suffers"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 flex flex-wrap gap-1.5",
								children: hurt.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "suffer",
									children: l.ticker
								}, l.ticker))
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-surface p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "stamp text-[10px] text-subtle",
								children: "Sensors"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-3 space-y-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "Walk-back"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: wb ? "text-warn" : "text-earn",
											children: wb ? "Active — 100% XSTR" : "Inactive"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "PMI"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "tabular",
											children: store.pmi.toFixed(1)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "2s10s"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: store.curveInverted ? "Inverted" : "Not inverted" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "GT30 / IDTL flag"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
											className: idtlFlag(store.gt30) ? "text-warn tabular" : "tabular",
											children: [
												store.gt30.toFixed(3),
												"% ",
												idtlFlag(store.gt30) ? "· flag" : ""
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "NAV"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
											className: "tabular",
											children: ["£", store.nav.toLocaleString("en-GB")]
										})]
									})
								]
							}),
							idtlFlag(store.gt30) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs leading-relaxed text-warn",
								children: "Duration-hit flag. Do not sell. The spring is being compressed further."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs leading-relaxed text-subtle",
								children: idtlWatchCopy(store.gt30)
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "stamp text-[11px] text-subtle",
					children: "This month · the 3rd"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display mt-2 text-2xl",
					children: "Contribution routing"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "ghost",
					size: "sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/decide",
						children: "Full protocol"
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerdictCard, { verdict: routing })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "grid gap-4 sm:grid-cols-3",
				children: [
					{
						k: "Look-through equity",
						v: "~57%"
					},
					{
						k: "Planning drawdown",
						v: "30–35%"
					},
					{
						k: store.pieMode === "revised" ? "2022 stress (revised)" : "2022 stress (lock)",
						v: store.pieMode === "revised" ? "−2.11%" : "−3.69%"
					}
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-surface px-5 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.14em] text-subtle",
						children: s.k
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display mt-2 text-2xl tabular",
						children: s.v
					})]
				}, s.k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "max-w-2xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg leading-relaxed text-muted italic",
					children: FARMER
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm leading-relaxed text-subtle",
					children: IF_THEN
				})]
			})
		]
	});
}
//#endregion
export { CommandPage as component };
