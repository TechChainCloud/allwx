import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as SIZE_GATES, S as REVISED_PIE, g as LOCKED_PIE, n as cn, o as selectPie, s as useInvictus, y as PERMANENTLY_DEAD } from "./router-WnV7qMiD.mjs";
import { t as Badge } from "./badge-BsNt2dFM.mjs";
import { c as verdictAddLine, d as verdictSell, f as verdictSizeGate, l as verdictAutoInvest, o as routeContribution, p as walkBackActive, t as Button, u as verdictDead } from "./engine-BIGKsWsh.mjs";
import { t as Segment } from "./segment-hSgKujC5.mjs";
import { t as VerdictCard } from "./verdict-card-DBxXqytc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/decide-CNdJUW7V.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var INTENTS = [
	{
		id: "contribute",
		title: "Route this month’s contribution",
		blurb: "The 3rd does the work. Nothing is sold."
	},
	{
		id: "sell",
		title: "Should I sell a line?",
		blurb: "The signed sentence already answered."
	},
	{
		id: "autoinvest",
		title: "Change AutoInvest",
		blurb: "Lock file first. Decision date first."
	},
	{
		id: "walkback",
		title: "Has walk-back fired?",
		blurb: "PMI < 50 and 2s10s inverted."
	},
	{
		id: "addline",
		title: "Add a 17th line",
		blurb: "No 17th personality."
	},
	{
		id: "gates",
		title: "Size-gate a replacement",
		blurb: "FLOT, VHYL, ROLL — gates, not orders."
	},
	{
		id: "dead",
		title: "Revive a dead idea",
		blurb: "D-Prime, IITU, crypto, 8% planning return."
	}
];
function DecidePage() {
	const store = useInvictus();
	const pie = selectPie(store.pieMode);
	const [intent, setIntent] = (0, import_react.useState)("contribute");
	const [sellTicker, setSellTicker] = (0, import_react.useState)("VAGS");
	const [addTicker, setAddTicker] = (0, import_react.useState)("IITU");
	const [gateId, setGateId] = (0, import_react.useState)("FLOT");
	const [deadId, setDeadId] = (0, import_react.useState)(PERMANENTLY_DEAD[0].id);
	const allTickers = (0, import_react.useMemo)(() => {
		const set = /* @__PURE__ */ new Set();
		for (const l of LOCKED_PIE) set.add(l.ticker);
		for (const l of REVISED_PIE) set.add(l.ticker);
		return [...set];
	}, []);
	const verdict = (0, import_react.useMemo)(() => {
		switch (intent) {
			case "contribute": return routeContribution(pie, store);
			case "sell": return verdictSell(pie, sellTicker);
			case "autoinvest": return verdictAutoInvest(store);
			case "walkback":
				if (walkBackActive(store.pmi, store.curveInverted)) return routeContribution(pie, store);
				return {
					kind: "hold",
					stamp: "WALK-BACK INACTIVE",
					rule: "PMI < 50 AND 2s10s inverted. Both must be true.",
					reason: `PMI is ${store.pmi.toFixed(1)}${store.pmi < 50 ? " (below 50)" : " (above 50)"} and the curve is ${store.curveInverted ? "inverted" : "not inverted"}. Contributions follow floors, caps and target weights. Satellites are not zeroed.`,
					ifThen: "If the front line is intact, the reserve stays the reserve. Do not hide in cash because a single line had a bad month."
				};
			case "addline": return verdictAddLine(addTicker);
			case "gates": return verdictSizeGate(gateId, store.nav);
			case "dead": return verdictDead(deadId);
		}
	}, [
		intent,
		pie,
		store,
		sellTicker,
		addTicker,
		gateId,
		deadId
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "stamp text-[11px] text-subtle",
						children: "Protocol"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-3 text-4xl tracking-tight",
						children: "Decide"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: "Name the action. The machine applies the lock file. A briefing is not a change log entry."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2 sm:grid-cols-2",
				children: INTENTS.map((item) => {
					const on = item.id === intent;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setIntent(item.id),
						className: cn("rounded-xl px-4 py-4 text-left transition-colors duration-150", on ? "bg-accent text-accent-fg" : "bg-surface hover:bg-elevated"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("mt-1 text-xs leading-relaxed", on ? "text-accent-fg/75" : "text-muted"),
							children: item.blurb
						})]
					}, item.id);
				})
			}),
			intent === "contribute" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ControlsPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "This month’s contribution",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						value: store.contribution,
						onChange: store.setContribution,
						prefix: "£",
						step: 50,
						min: 0
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "PMI",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						value: store.pmi,
						onChange: store.setPmi,
						step: .1,
						min: 20,
						max: 80
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "2s10s curve",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
						ariaLabel: "Curve",
						value: store.curveInverted ? "inv" : "norm",
						onChange: (v) => store.setCurveInverted(v === "inv"),
						options: [{
							value: "norm",
							label: "Not inverted"
						}, {
							value: "inv",
							label: "Inverted"
						}]
					})
				})
			] }) : null,
			intent === "sell" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ControlsPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Line under review",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					value: sellTicker,
					onChange: (e) => setSellTicker(e.target.value),
					className: "h-11 w-full rounded-md bg-inset px-3 text-sm text-fg shadow-[var(--shadow-border)]",
					children: allTickers.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: t,
						children: t
					}, t))
				})
			}) }) : null,
			intent === "walkback" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ControlsPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "PMI",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
					value: store.pmi,
					onChange: store.setPmi,
					step: .1,
					min: 20,
					max: 80
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "2s10s curve",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
					ariaLabel: "Curve",
					value: store.curveInverted ? "inv" : "norm",
					onChange: (v) => store.setCurveInverted(v === "inv"),
					options: [{
						value: "norm",
						label: "Not inverted"
					}, {
						value: "inv",
						label: "Inverted"
					}]
				})
			})] }) : null,
			intent === "addline" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ControlsPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Proposed ticker",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: addTicker,
					onChange: (e) => setAddTicker(e.target.value.toUpperCase()),
					className: "h-11 w-full rounded-md bg-inset px-3 text-sm tracking-wide text-fg shadow-[var(--shadow-border)]",
					placeholder: "IITU"
				})
			}) }) : null,
			intent === "gates" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ControlsPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Gate",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
					ariaLabel: "Size gate",
					value: gateId,
					onChange: (v) => setGateId(v),
					options: SIZE_GATES.map((g) => ({
						value: g.id,
						label: g.id
					}))
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "ISA NAV",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
					value: store.nav,
					onChange: store.setNav,
					prefix: "£",
					step: 50,
					min: 0
				})
			})] }) : null,
			intent === "dead" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ControlsPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: PERMANENTLY_DEAD.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setDeadId(d.id),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: deadId === d.id ? "invert" : "default",
						children: d.name
					})
				}, d.id))
			}) }) : null,
			intent === "autoinvest" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Working pie:",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-fg",
						children: store.pieMode === "revised" ? "Revised" : "12 September lock"
					}),
					store.signedAt ? " · signed" : " · unsigned"
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerdictCard, { verdict }),
			intent === "contribute" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeightsEditor, {}) : null
		]
	});
}
function ControlsPanel({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-4 rounded-xl bg-surface p-4 sm:grid-cols-3 sm:p-5",
		children
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-2 block text-[11px] uppercase tracking-[0.14em] text-subtle",
			children: label
		}), children]
	});
}
function NumberField({ value, onChange, prefix, step = 1, min, max }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [prefix ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm text-subtle",
			children: prefix
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "number",
			value: Number.isFinite(value) ? value : 0,
			step,
			min,
			max,
			onChange: (e) => onChange(Number(e.target.value)),
			className: cn("h-11 w-full rounded-md bg-inset text-sm tabular text-fg shadow-[var(--shadow-border)]", prefix ? "pl-7 pr-3" : "px-3")
		})]
	});
}
function WeightsEditor() {
	const store = useInvictus();
	const pie = selectPie(store.pieMode);
	const sum = pie.reduce((s, l) => s + (store.weights[l.ticker] ?? l.weight), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 flex items-end justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-xl",
			children: "Current weights"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-xs text-muted",
			children: [
				"Drift the pie to see how the 3rd rebalances. Sum ",
				sum.toFixed(1),
				"%."
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			size: "sm",
			onClick: store.resetWeights,
			children: "Reset to target"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-xl bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-[1fr_4.5rem_5.5rem] gap-2 border-b border-line px-4 py-2 text-[10px] uppercase tracking-[0.14em] text-subtle",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-right",
					children: "Now"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-right",
					children: "Target"
				})
			]
		}), pie.map((l) => {
			const w = store.weights[l.ticker] ?? l.weight;
			const drift = w - l.weight;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-[1fr_4.5rem_5.5rem] items-center gap-2 border-b border-line/70 px-4 py-2 last:border-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: l.ticker
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] text-subtle",
						children: [
							l.floor,
							"–",
							l.cap,
							"%",
							w < l.floor ? " · below floor" : w > l.cap ? " · above cap" : ""
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						step: .5,
						min: 0,
						max: 60,
						value: w,
						onChange: (e) => store.setWeight(l.ticker, Number(e.target.value)),
						className: "h-10 rounded-sm bg-inset px-2 text-right text-sm tabular text-fg"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("text-right text-sm tabular", drift > .2 ? "text-warn" : drift < -.2 ? "text-hold" : "text-muted"),
						children: l.weight.toFixed(1)
					})
				]
			}, l.ticker);
		})]
	})] });
}
//#endregion
export { DecidePage as component };
