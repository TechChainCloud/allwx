import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as SIGNED_SENTENCE_LOCKED, T as SIGN_AFTER, _ as LOCK_ENTRIES, c as AUTOINVEST_ON, f as FOMC_AT, h as IF_THEN, n as cn, p as GOVERNANCE, s as useInvictus, w as SIGNED_SENTENCE_REVISED, y as PERMANENTLY_DEAD } from "./router-WnV7qMiD.mjs";
import { t as Badge } from "./badge-BsNt2dFM.mjs";
import { i as isFomcPassed, t as Button } from "./engine-BIGKsWsh.mjs";
import { t as Segment } from "./segment-hSgKujC5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lock-DSmTHuLx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LockPage() {
	const store = useInvictus();
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const fomc = isFomcPassed();
	const canSign = fomc && confirm.trim().toUpperCase() === "SIGN";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "stamp text-[11px] text-subtle",
						children: "Lock file"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-3 text-4xl tracking-tight",
						children: "The only document that authorises AutoInvest."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: "A briefing, an analysis, a conversation — none of these are a change log entry. Decision date precedes change date. Always."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "font-display max-w-3xl border-l border-line pl-5 text-lg leading-relaxed italic",
				children: store.signedAt ? SIGNED_SENTENCE_REVISED : SIGNED_SENTENCE_LOCKED
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-5 sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "stamp text-[10px] text-subtle",
					children: "Working pie"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segment, {
						ariaLabel: "Working pie",
						value: store.pieMode,
						onChange: (v) => store.setPieMode(v),
						options: [{
							value: "locked",
							label: "12 Sep lock"
						}, {
							value: "revised",
							label: "Revised preview"
						}]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-sm text-xs leading-relaxed text-muted",
						children: "Preview is a briefing. It does not change AutoInvest. Signature switches the working pie to Revised."
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "font-display text-2xl",
				children: ["Four entries — ", SIGN_AFTER]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-4 space-y-2",
				children: LOCK_ENTRIES.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl bg-surface px-5 py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "stamp text-[10px] text-subtle",
							children: ["Entry ", e.n]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-fg",
							children: [
								e.from,
								" → ",
								e.to
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: e.reason
						})
					]
				}, e.n))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-inset p-5 shadow-[var(--shadow-border)] sm:p-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "stamp text-[11px] text-warn",
						children: store.signedAt ? "Signed" : fomc ? "Ready to sign" : "Blocked until FOMC"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display mt-3 text-2xl",
						children: "Sign the sentence"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-prose text-sm leading-relaxed text-muted",
						children: fomc ? `FOMC has occurred. Type SIGN to record the lock. AutoInvest changes on ${AUTOINVEST_ON} — the next calendar day — not today.` : `The FOMC is ${new Date(FOMC_AT).toLocaleString("en-GB", { timeZone: "Europe/London" })}. Protocol: sign after, not before. The box stays closed.`
					}),
					store.signedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-earn",
							children: [
								"Recorded ",
								new Date(store.signedAt).toLocaleString("en-GB"),
								". Working pie is Revised."
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: store.unsign,
							children: "Revert to unsigned (testing)"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-col gap-3 sm:flex-row sm:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: confirm,
							onChange: (e) => setConfirm(e.target.value),
							disabled: !fomc,
							placeholder: fomc ? "Type SIGN" : "Opens after FOMC",
							className: "h-11 max-w-xs rounded-md bg-surface px-3 text-sm tracking-[0.2em] text-fg shadow-[var(--shadow-border)] uppercase placeholder:tracking-normal placeholder:text-subtle disabled:opacity-40",
							"aria-label": "Type SIGN to confirm"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: !canSign,
							onClick: () => store.sign(),
							children: "Record lock file"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display mt-6 text-[15px] leading-relaxed text-muted italic",
						children: IF_THEN
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Governance"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid gap-3 sm:grid-cols-2",
				children: GOVERNANCE.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl bg-surface px-5 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-fg",
						children: g.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: g.body
					})]
				}, g.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Permanently dead"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 space-y-2",
				children: PERMANENTLY_DEAD.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-col gap-1 rounded-xl bg-surface px-5 py-4 sm:flex-row sm:items-baseline sm:gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "suffer",
						children: d.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: d.reason
					})]
				}, d.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("text-xs text-subtle"),
				children: "Locked 12 September 2026, 16:55 BST. Master English edition. Sleep well."
			})
		]
	});
}
//#endregion
export { LockPage as component };
