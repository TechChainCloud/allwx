//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DftiKQU8.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/decide",
			"/lines",
			"/lock",
			"/path"
		],
		preloads: ["/assets/index-CKCG16BE.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CKCG16BE.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-C5I1MWAo.js",
			"/assets/badge-A0IgXqs7.js",
			"/assets/engine-CNgfvbs8.js",
			"/assets/segment-Ce_T_XvT.js",
			"/assets/verdict-card-DiQfdXpK.js"
		]
	},
	"/decide": {
		filePath: "/workspace/src/routes/decide.tsx",
		children: void 0,
		preloads: [
			"/assets/decide-DSnILeNW.js",
			"/assets/badge-A0IgXqs7.js",
			"/assets/engine-CNgfvbs8.js",
			"/assets/segment-Ce_T_XvT.js",
			"/assets/verdict-card-DiQfdXpK.js"
		]
	},
	"/lines": {
		filePath: "/workspace/src/routes/lines.tsx",
		children: void 0,
		preloads: ["/assets/lines-BfBQnAZr.js", "/assets/badge-A0IgXqs7.js"]
	},
	"/lock": {
		filePath: "/workspace/src/routes/lock.tsx",
		children: void 0,
		preloads: [
			"/assets/lock-BiqWt6Dq.js",
			"/assets/badge-A0IgXqs7.js",
			"/assets/engine-CNgfvbs8.js",
			"/assets/segment-Ce_T_XvT.js"
		]
	},
	"/path": {
		filePath: "/workspace/src/routes/path.tsx",
		children: void 0,
		preloads: ["/assets/path-D4J7fzir.js", "/assets/engine-CNgfvbs8.js"]
	}
} });
//#endregion
export { tsrStartManifest };
